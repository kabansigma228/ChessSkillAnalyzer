# GlenMate 2.0.2 (candidate)

Android Kotlin/Jetpack Compose chess analysis app.

Changes in this candidate: minimal three-action home screen with slow ambient chess-piece animation; game/settings/trainer navigation; selectable human side and setup-piece color; legal move validation for standard piece movement, check exposure, castling, en passant, and promotion; side-to-move display; Stockfish best-move arrow overlay; theme and accent selection.

The CI workflow in the repository builds Stockfish for arm64 and patches the launcher to use the packaged native library.

Important: SAN PGN parsing, full game history, comprehensive checkmate/stalemate/draw UI, coach lessons, and full six-language localization are not implemented in this candidate. This source archive has not been built with Android Gradle Plugin in this environment; run GitHub Actions before installing.
