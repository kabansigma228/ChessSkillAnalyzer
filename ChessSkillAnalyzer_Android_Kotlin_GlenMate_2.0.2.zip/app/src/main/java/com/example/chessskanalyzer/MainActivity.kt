package com.example.chessskanalyzer

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState); setContent { GlenMateApp() } }
}

private val Forest = Color(0xFF14251F)
private val Panel = Color(0xFF20372D)
private val Gold = Color(0xFFD6B66B)

@Composable
fun GlenMateApp() {
    val ctx = androidx.compose.ui.platform.LocalContext.current
    val scope = rememberCoroutineScope()
    var page by remember { mutableStateOf("home") }
    var fen by remember { mutableStateOf(ChessPosition.START_FEN) }
    var selected by remember { mutableStateOf<Int?>(null) }
    var edit by remember { mutableStateOf(false) }
    var editColor by remember { mutableStateOf('w') }
    var piece by remember { mutableStateOf('Q') }
    var humanColor by remember { mutableStateOf('w') }
    var depth by remember { mutableIntStateOf(18) }
    var best by remember { mutableStateOf("—") }
    var eval by remember { mutableStateOf("—") }
    var pv by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var message by remember { mutableStateOf("Готово к игре") }
    var showArrow by remember { mutableStateOf(true) }
    var dark by remember { mutableStateOf(true) }
    var accent by remember { mutableIntStateOf(0) }
    val accentColor = listOf(Gold, Color(0xFF80B9E8), Color(0xFF9CCB9E), Color(0xFFC5A0E8), Color(0xFFE69A86))[accent]
    val scheme = if (dark) darkColorScheme(primary=accentColor, background=Forest, surface=Panel) else lightColorScheme(primary=Color(0xFF426B55), background=Color(0xFFF4F1E8), surface=Color.White)
    MaterialTheme(colorScheme=scheme) {
        Surface(Modifier.fillMaxSize(), color=MaterialTheme.colorScheme.background) {
            when(page) {
                "home" -> HomeScreen(onPlay={page="game"}, onCoach={page="coach"}, onSettings={page="settings"}, accent=accentColor)
                "settings" -> Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp), verticalArrangement=Arrangement.spacedBy(16.dp)) {
                    Header("Настройки", {page="home"})
                    Text("Оформление", fontWeight=FontWeight.Bold)
                    Row(verticalAlignment=Alignment.CenterVertically) { Text("Тёмная тема", Modifier.weight(1f)); Switch(dark,{dark=it}) }
                    Text("Акцентный цвет")
                    Row(horizontalArrangement=Arrangement.spacedBy(12.dp)) { listOf(Gold,Color(0xFF80B9E8),Color(0xFF9CCB9E),Color(0xFFC5A0E8),Color(0xFFE69A86)).forEachIndexed { i,c -> Box(Modifier.size(36.dp).background(c, RoundedCornerShape(50)).clickable { accent=i }.border(if(accent==i) 3.dp else 0.dp, Color.White, RoundedCornerShape(50))) } }
                    Text("Язык интерфейса: русский (другие переводы добавляются отдельно)", color=MaterialTheme.colorScheme.onSurfaceVariant)
                }
                "coach" -> Column(Modifier.fillMaxSize().padding(20.dp), verticalArrangement=Arrangement.spacedBy(14.dp)) {
                    Header("Тренер", {page="home"})
                    Text("Тренировочный раздел GlenMate", style=MaterialTheme.typography.headlineSmall)
                    Text("Здесь доступны анализ позиции и подсказка лучшего хода. Полноценные уроки и Puzzle Rush пока не входят в эту сборку.")
                    Button(onClick={page="game"}) { Text("Открыть доску") }
                }
                else -> Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(14.dp), verticalArrangement=Arrangement.spacedBy(10.dp)) {
                    Header("Игра", {page="home"})
                    Row(verticalAlignment=Alignment.CenterVertically) {
                        Text(if(fen.split(" ").getOrNull(1)=="w") "Ход белых" else "Ход чёрных", Modifier.weight(1f), style=MaterialTheme.typography.titleLarge, fontWeight=FontWeight.Bold)
                        Text("Ты играешь: ${if(humanColor=='w') "белыми" else "чёрными"}")
                    }
                    Row(horizontalArrangement=Arrangement.spacedBy(8.dp)) {
                        FilterChip(selected=humanColor=='w',onClick={humanColor='w'},label={Text("Белые")})
                        FilterChip(selected=humanColor=='b',onClick={humanColor='b'},label={Text("Чёрные")})
                        FilterChip(selected=edit,onClick={edit=!edit;selected=null},label={Text("Расстановка")})
                    }
                    if(edit) {
                        Text("Цвет расставляемых фигур")
                        Row { FilterChip(selected=editColor=='w',onClick={editColor='w';piece=piece.uppercaseChar()},label={Text("Белые")}); Spacer(Modifier.width(8.dp)); FilterChip(selected=editColor=='b',onClick={editColor='b';piece=piece.lowercaseChar()},label={Text("Чёрные")}) }
                        Row(Modifier.horizontalScroll(rememberScrollState()),horizontalArrangement=Arrangement.spacedBy(2.dp)) { listOf('K','Q','R','B','N','P','.').forEach { q -> TextButton(onClick={piece=if(editColor=='w') q else q.lowercaseChar()}) { Text(if(q=='.') "⌫" else ChessPosition.glyph(if(editColor=='w') q else q.lowercaseChar()),fontSize=22.sp) } } }
                    }
                    ChessBoard(fen,selected,best.takeIf { showArrow },onSquare={sq ->
                        if(edit) { val b=ChessPosition.boardChars(fen).toMutableList(); b[sq]=piece; fen=ChessPosition.withBoard(fen,b); best="—"; selected=null }
                        else if(selected==null) { if(ChessPosition.boardChars(fen)[sq]!='.') selected=sq }
                        else { val from=selected!!; val next=ChessPosition.applyUci(fen,ChessPosition.squareName(from)+ChessPosition.squareName(sq)); if(next!=null){fen=next;message="Ход выполнен";best="—"}else message="Недопустимый ход";selected=null }
                    })
                    Row(verticalAlignment=Alignment.CenterVertically) { Text("Показывать стрелку",Modifier.weight(1f)); Switch(showArrow,{showArrow=it}) }
                    Text("Глубина анализа: $depth")
                    Slider(value=depth.toFloat(),onValueChange={depth=it.toInt()},valueRange=10f..24f,steps=13)
                    Button(onClick={busy=true;message="Анализ позиции…";scope.launch { val r=withContext(Dispatchers.IO){StockfishEngine(ctx).analyze(fen,depth)};best=r.bestMove;eval=r.evaluation;pv=r.pv;message=r.message;busy=false }},enabled=!busy && ChessPosition.isPlausibleFen(fen),modifier=Modifier.fillMaxWidth()) { Text(if(busy) "Анализ…" else "Найти лучший ход") }
                    Card { Column(Modifier.padding(14.dp),verticalArrangement=Arrangement.spacedBy(5.dp)) { Text("Лучший ход: ${best.takeIf{it!="—"}?.let{ChessPosition.uciLabel(it)} ?: "—"}",style=MaterialTheme.typography.titleLarge,fontWeight=FontWeight.Bold); Text("Оценка: $eval"); Text("Вариант: $pv"); Text(message,color=MaterialTheme.colorScheme.onSurfaceVariant) } }
                    OutlinedButton(onClick={fen=ChessPosition.START_FEN;best="—";selected=null;message="Начальная позиция"},modifier=Modifier.fillMaxWidth()) { Text("Новая партия") }
                }
            }
        }
    }
}

@Composable private fun Header(title:String,back:()->Unit) { Row(verticalAlignment=Alignment.CenterVertically) { Text("‹",Modifier.clickable{back()}.padding(end=12.dp),fontSize=30.sp); Text(title,style=MaterialTheme.typography.headlineMedium,fontWeight=FontWeight.Bold) } }

@Composable private fun HomeScreen(onPlay:()->Unit,onCoach:()->Unit,onSettings:()->Unit,accent:Color) {
    val infinite= rememberInfiniteTransition(label="float")
    val drift by infinite.animateFloat(initialValue=-12f,targetValue=12f,animationSpec=infiniteRepeatable(tween(6500,easing=LinearEasing),RepeatMode.Reverse),label="drift")
    Box(Modifier.fillMaxSize().background(Forest)) {
        Text("♞",Modifier.align(Alignment.TopEnd).offset(x=drift.dp,y=35.dp),fontSize=116.sp,color=Color.White.copy(alpha=.045f))
        Text("♜",Modifier.align(Alignment.BottomStart).offset(x=(-drift).dp,y=(-20).dp),fontSize=105.sp,color=Color.White.copy(alpha=.045f))
        Text("♝",Modifier.align(Alignment.CenterEnd).offset(y=drift.dp),fontSize=82.sp,color=Color.White.copy(alpha=.04f))
        Column(Modifier.fillMaxSize().padding(horizontal=28.dp),verticalArrangement=Arrangement.Center,horizontalAlignment=Alignment.CenterHorizontally) {
            Text("GlenMate",fontSize=38.sp,fontWeight=FontWeight.Bold,color=Color(0xFFF3EBDD))
            Text("THINK • PLAY • IMPROVE",fontSize=11.sp,letterSpacing=3.sp,color=accent,modifier=Modifier.padding(top=8.dp,bottom=42.dp))
            HomeButton("♟   ИГРА","Играй и анализируй позиции",accent,onPlay)
            Spacer(Modifier.height(14.dp)); HomeButton("♘   ТРЕНЕР","Разбор и шахматные подсказки",accent,onCoach)
            Spacer(Modifier.height(14.dp)); HomeButton("⚙   НАСТРОЙКИ","Оформление приложения",accent,onSettings)
        }
    }
}
@Composable private fun HomeButton(title:String,subtitle:String,accent:Color,onClick:()->Unit) { Card(Modifier.fillMaxWidth().clickable{onClick()},shape=RoundedCornerShape(18.dp),colors=CardDefaults.cardColors(containerColor=Color(0xFF20372D))) { Column(Modifier.padding(18.dp)) { Text(title,color=accent,fontWeight=FontWeight.Bold,fontSize=18.sp); Text(subtitle,color=Color(0xFFD4DED7),fontSize=12.sp) } } }

@Composable private fun ChessBoard(fen:String,selected:Int?,best:String?,onSquare:(Int)->Unit) {
    val cells=remember(fen){ChessPosition.boardChars(fen)}
    val arrowFrom=best?.takeIf{it.length>=4}?.let{ChessPosition.squareIndex(it.substring(0,2))}
    val arrowTo=best?.takeIf{it.length>=4}?.let{ChessPosition.squareIndex(it.substring(2,4))}
    Box(Modifier.fillMaxWidth().aspectRatio(1f)) {
        Column(Modifier.fillMaxSize()) { for(r in 0..7) Row(Modifier.weight(1f)) { for(c in 0..7) { val i=r*8+c; val marked=i==arrowFrom||i==arrowTo; val bg=when { i==selected->Color(0xFFE9D46C); marked->Color(0xFFB8C879); (r+c)%2==0->Color(0xFFE8DCC4);else->Color(0xFF77966D) }; Box(Modifier.weight(1f).fillMaxHeight().background(bg).clickable{onSquare(i)},contentAlignment=Alignment.Center) { val pc=cells[i]; if(pc!='.') Text(ChessPosition.glyph(pc),fontSize=29.sp,color=if(pc.isUpperCase()) Color(0xFFFAF7EE) else Color(0xFF172019)) } } } }
        if(arrowFrom!=null && arrowTo!=null) androidx.compose.foundation.Canvas(Modifier.fillMaxSize()) {
            val w=size.width/8f; val h=size.height/8f
            val sx=(arrowFrom%8+.5f)*w; val sy=(arrowFrom/8+.5f)*h
            val ex=(arrowTo%8+.5f)*w; val ey=(arrowTo/8+.5f)*h
            drawLine(Color(0xDD176B35),androidx.compose.ui.geometry.Offset(sx,sy),androidx.compose.ui.geometry.Offset(ex,ey),strokeWidth=w*.10f)
            val angle=kotlin.math.atan2(ey-sy,ex-sx); val len=w*.27f
            val p1=androidx.compose.ui.geometry.Offset(ex-len*kotlin.math.cos(angle-.55f),ey-len*kotlin.math.sin(angle-.55f))
            val p2=androidx.compose.ui.geometry.Offset(ex-len*kotlin.math.cos(angle+.55f),ey-len*kotlin.math.sin(angle+.55f))
            val path=Path().apply { moveTo(ex,ey);lineTo(p1.x,p1.y);lineTo(p2.x,p2.y);close() }
            drawPath(path,Color(0xDD176B35))
        }
    }
}

data class EngineResult(val bestMove: String, val evaluation: String, val pv: String, val message: String)

class StockfishEngine(private val context: android.content.Context) {
    fun analyze(fen: String, depth: Int): EngineResult = try {
        val target = java.io.File(context.applicationInfo.nativeLibraryDir, "libstockfish.so")
        if (!target.exists()) error("Stockfish binary not packaged")
        val process = ProcessBuilder(target.absolutePath).redirectErrorStream(true).start()
        val writer = process.outputStream.bufferedWriter()
        val reader = process.inputStream.bufferedReader()
        fun send(s: String) { writer.write(s); writer.newLine(); writer.flush() }
        send("uci")
        var line: String?
        var ready = false
        while (true) { line = reader.readLine() ?: break; if (line == "uciok") { ready = true; break } }
        if (!ready) error("Stockfish не ответил на UCI")
        send("isready")
        while (reader.readLine()?.trim() != "readyok") { }
        send("position fen $fen"); send("go depth $depth")
        var best = "—"; var score = "—"; var variation = ""
        while (true) {
            line = reader.readLine() ?: break
            if (line!!.startsWith("info ") && line!!.contains(" score ")) {
                val t = line!!.split(" "); val si = t.indexOf("score")
                if (si >= 0 && si+2 < t.size) score = when(t[si+1]) {
                    "cp" -> "%+.2f пешки".format(java.util.Locale.US, t[si+2].toInt()/100.0)
                    "mate" -> "мат в ${t[si+2]}"
                    else -> score
                }
                val pi = t.indexOf("pv"); if (pi >= 0) variation = t.drop(pi+1).take(12).joinToString(" ")
            }
            if (line!!.startsWith("bestmove ")) { best = line!!.split(" ").getOrNull(1) ?: "—"; break }
        }
        send("quit"); process.waitFor()
        EngineResult(best, score, variation, "Анализ завершён на глубине $depth.")
    } catch (e: Exception) {
        EngineResult("—", "—", "", "Stockfish не найден или не запустился: ${e.message}. Добавьте бинарник для ABI устройства.")
    }
}

object ChessPosition {
    const val START_FEN="rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1"
    fun boardChars(fen:String):List<Char>{ val ranks=fen.trim().substringBefore(' ').split('/');if(ranks.size!=8)return List(64){'.'};val out=mutableListOf<Char>();ranks.forEach{it.forEach{c->if(c.isDigit())repeat(c.digitToInt()){out.add('.')}else out.add(c)}};return if(out.size==64)out else List(64){'.'} }
    fun squareName(i:Int)="${'a'+i%8}${8-i/8}"
    fun squareIndex(s:String):Int=if(s.length==2&&s[0] in 'a'..'h'&&s[1] in '1'..'8')(8-(s[1]-'0'))*8+(s[0]-'a') else -1
    fun glyph(p:Char)=when(p){'K'->"♔";'Q'->"♕";'R'->"♖";'B'->"♗";'N'->"♘";'P'->"♙";'k'->"♚";'q'->"♛";'r'->"♜";'b'->"♝";'n'->"♞";'p'->"♟";else->""}
    fun isPlausibleFen(f:String):Boolean { val a=f.trim().split(Regex("\\s+"));if(a.size!=6||a[1] !in listOf("w","b"))return false;val rs=a[0].split('/');if(rs.size!=8)return false;return rs.all{var n=0;for(c in it){if(c.isDigit())n+=c.digitToInt() else if(c in "KQRBNPkqrbnp")n++ else return@all false};n==8} }
    fun withBoard(f:String,b:List<Char>):String { val board=(0..7).joinToString("/"){r->val x=StringBuilder();var e=0;b.subList(r*8,r*8+8).forEach{if(it=='.')e++ else{if(e>0)x.append(e);e=0;x.append(it)}};if(e>0)x.append(e);x.toString()};val a=f.trim().split(Regex("\\s+"));return "$board ${a.getOrNull(1)?:"w"} ${a.getOrNull(2)?:"-"} ${a.getOrNull(3)?:"-"} ${a.getOrNull(4)?:"0"} ${a.getOrNull(5)?:"1"}" }
    fun uciLabel(u:String)=if(u.length>=4)"${u.substring(0,2)} → ${u.substring(2,4)}"+(if(u.length==5)"=${u[4].uppercase()}" else "") else u
    private fun inside(r:Int,c:Int)=r in 0..7&&c in 0..7
    private fun attacked(b:List<Char>,sq:Int,byWhite:Boolean):Boolean { val r=sq/8;val c=sq%8;val pawn=if(byWhite)'P' else 'p';val pr=if(byWhite)r+1 else r-1;for(dc in listOf(-1,1))if(inside(pr,c+dc)&&b[pr*8+c+dc]==pawn)return true;val knight=if(byWhite)'N' else 'n';for((dr,dc) in listOf(-2 to -1,-2 to 1,-1 to -2,-1 to 2,1 to -2,1 to 2,2 to -1,2 to 1))if(inside(r+dr,c+dc)&&b[(r+dr)*8+c+dc]==knight)return true;val king=if(byWhite)'K' else 'k';for(dr in -1..1)for(dc in -1..1)if((dr!=0||dc!=0)&&inside(r+dr,c+dc)&&b[(r+dr)*8+c+dc]==king)return true;for((dr,dc) in listOf(-1 to 0,1 to 0,0 to -1,0 to 1,-1 to -1,-1 to 1,1 to -1,1 to 1)){var rr=r+dr;var cc=c+dc;var first=true;while(inside(rr,cc)){val x=b[rr*8+cc];if(x!='.'){if(x.isUpperCase()==byWhite&&(x.uppercaseChar()=='Q'||(first&&x.uppercaseChar()=='K')||(dr==0||dc==0)&&x.uppercaseChar()=='R'||(dr!=0&&dc!=0)&&x.uppercaseChar()=='B'))return true;break};first=false;rr+=dr;cc+=dc}};return false }
    private fun kingSafe(b:List<Char>,white:Boolean):Boolean { val k=if(white)'K' else 'k';val i=b.indexOf(k);return i>=0&&!attacked(b,i,!white) }
    fun applyUci(fen:String,uci:String):String? { if(!isPlausibleFen(fen)||uci.length !in 4..5)return null;val a=fen.trim().split(Regex("\\s+"));val b=boardChars(fen).toMutableList();val from=squareIndex(uci.substring(0,2));val to=squareIndex(uci.substring(2,4));if(from<0||to<0||from==to)return null;val p=b[from];if(p=='.')return null;val white=a[1]=="w";if(p.isUpperCase()!=white)return null;val target=b[to];if(target!='.'&&target.isUpperCase()==white)return null;val fr=from/8;val fc=from%8;val tr=to/8;val tc=to%8;val dr=tr-fr;val dc=tc-fc;val kind=p.uppercaseChar();var epCapture=false;var castle=false
        val valid=when(kind){'P'->{val d=if(white)-1 else 1;val start=if(white)6 else 1;if(dc==0&&dr==d&&target=='.')true else if(dc==0&&fr==start&&dr==2*d&&target=='.'&&b[(fr+d)*8+fc]=='.')true else if(kotlin.math.abs(dc)==1&&dr==d&&target!='.')true else if(kotlin.math.abs(dc)==1&&dr==d&&target=='.'&&a[3]==uci.substring(2,4)){epCapture=true;true}else false};'N'->(kotlin.math.abs(dr)==2&&kotlin.math.abs(dc)==1)||(kotlin.math.abs(dr)==1&&kotlin.math.abs(dc)==2);'B'->kotlin.math.abs(dr)==kotlin.math.abs(dc)&&clear(b,fr,fc,tr,tc);'R'->(dr==0||dc==0)&&clear(b,fr,fc,tr,tc);'Q'->(dr==0||dc==0||kotlin.math.abs(dr)==kotlin.math.abs(dc))&&clear(b,fr,fc,tr,tc);'K'->{if(kotlin.math.abs(dc)==2&&dr==0){castle=true;val rights=a[2];val ks=white&&from==60&&to==62&&'K' in rights&&b[63]=='R'&&b[61]=='.'&&b[62]=='.'&&!attacked(b,60,false)&&!attacked(b,61,false)&&!attacked(b,62,false);val qs=white&&from==60&&to==58&&'Q' in rights&&b[56]=='R'&&b[59]=='.'&&b[58]=='.'&&b[57]=='.'&&!attacked(b,60,false)&&!attacked(b,59,false)&&!attacked(b,58,false);val ksb=!white&&from==4&&to==6&&'k' in rights&&b[7]=='r'&&b[5]=='.'&&b[6]=='.'&&!attacked(b,4,true)&&!attacked(b,5,true)&&!attacked(b,6,true);val qsb=!white&&from==4&&to==2&&'q' in rights&&b[0]=='r'&&b[3]=='.'&&b[2]=='.'&&b[1]=='.'&&!attacked(b,4,true)&&!attacked(b,3,true)&&!attacked(b,2,true);ks||qs||ksb||qsb}else kotlin.math.abs(dr)<=1&&kotlin.math.abs(dc)<=1};else->false}
        if(!valid)return null;if(kind=='P'&&tr==0||kind=='P'&&tr==7){if(uci.length!=5||uci[4].lowercaseChar() !in "qrbn")return null}else if(uci.length==5)return null
        b[from]='.';if(epCapture)b[if(white)to+8 else to-8]='.';b[to]=if(uci.length==5){if(white)uci[4].uppercaseChar() else uci[4].lowercaseChar()}else p
        if(castle){if(to==62){b[61]='R';b[63]='.'};if(to==58){b[59]='R';b[56]='.'};if(to==6){b[5]='r';b[7]='.'};if(to==2){b[3]='r';b[0]='.'}}
        if(!kingSafe(b,white))return null
        var rights=a[2];if(p=='K')rights=rights.replace("K","").replace("Q","");if(p=='k')rights=rights.replace("k","").replace("q","");if(from==63||to==63)rights=rights.replace("K","");if(from==56||to==56)rights=rights.replace("Q","");if(from==7||to==7)rights=rights.replace("k","");if(from==0||to==0)rights=rights.replace("q","");if(rights.isEmpty())rights="-"
        val ep=if(kind=='P'&&kotlin.math.abs(dr)==2)squareName((from+to)/2) else "-";val half=if(kind=='P'||target!='.')0 else (a[4].toIntOrNull()?:0)+1;val full=(a[5].toIntOrNull()?:1)+(if(!white)1 else 0);val next=if(white)'b' else 'w';return "${withBoard(fen,b).substringBefore(' ')} $next $rights $ep $half $full"
    }
    private fun clear(b:List<Char>,r:Int,c:Int,tr:Int,tc:Int):Boolean { val dr=(tr-r).compareTo(0);val dc=(tc-c).compareTo(0);var rr=r+dr;var cc=c+dc;while(rr!=tr||cc!=tc){if(b[rr*8+cc]!='.')return false;rr+=dr;cc+=dc};return true }
}

object PgnImporter {
    fun tryReadFenOrUci(pgn: String): String? {
        val fen = Regex("""(?m)^\[FEN\s+"([^"]+)"\]""").find(pgn)?.groupValues?.get(1)
        if(fen != null)return fen.takeIf { ChessPosition.isPlausibleFen(it) }
        val body=pgn.lines().filterNot { it.trim().startsWith("[") }.joinToString(" ")
            .replace(Regex("\\{[^}]*}")," ").replace(Regex("\\([^)]*\\)")," ")
        val moves=body.split(Regex("\\s+")).filter { it.isNotBlank() }
            .filterNot { it.matches(Regex("\\d+\\.{1,3}")) || it in listOf("1-0","0-1","1/2-1/2","*") }
        if(moves.isEmpty() || moves.any { !it.matches(Regex("[a-h][1-8][a-h][1-8][qrbnQRBN]?")) })return null
        var result=ChessPosition.START_FEN
        moves.forEach { result=ChessPosition.applyUci(result,it) ?: return null }
        return result
    }
}
