package com.example.chessskanalyzer

import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { GlenMateApp() }
    }
}

private enum class Page { HOME, GAME, COACH, SETTINGS }

@Composable
fun GlenMateApp() {
    var page by remember { mutableStateOf(Page.HOME) }
    var dark by remember { mutableStateOf(true) }
    var accentIndex by remember { mutableIntStateOf(0) }
    var language by remember { mutableStateOf("Русский") }
    val accents = listOf(Color(0xFF79C99E), Color(0xFF80B7FF), Color(0xFFC5A0FF), Color(0xFFFFB86B), Color(0xFFFF8F9B))
    val accent = accents[accentIndex]
    val scheme = if (dark) darkColorScheme(primary=accent, background=Color(0xFF101713), surface=Color(0xFF1B2821), onBackground=Color(0xFFF0F4F0), onSurface=Color(0xFFF0F4F0))
                 else lightColorScheme(primary=accent, background=Color(0xFFF4F6F2), surface=Color.White, onBackground=Color(0xFF172019), onSurface=Color(0xFF172019))
    MaterialTheme(colorScheme=scheme) {
        Box(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background)) {
            FloatingChessBackground()
            when(page) {
                Page.HOME -> HomeScreen(onGame={page=Page.GAME}, onCoach={page=Page.COACH}, onSettings={page=Page.SETTINGS})
                Page.GAME -> GameScreen(onBack={page=Page.HOME})
                Page.COACH -> CoachScreen(onBack={page=Page.HOME}, onOpenGame={page=Page.GAME})
                Page.SETTINGS -> SettingsScreen(onBack={page=Page.HOME}, dark=dark, onDark={dark=it}, accentIndex=accentIndex, onAccent={accentIndex=it}, language=language, onLanguage={language=it})
            }
        }
    }
}

@Composable
private fun FloatingChessBackground() {
    val symbols = listOf("♘", "♗", "♙", "♖", "♕")
    val transition = rememberInfiniteTransition(label="floating-pieces")
    val drift by transition.animateFloat(initialValue=0f, targetValue=1f, animationSpec=infiniteRepeatable(tween(18000, easing=LinearEasing), RepeatMode.Restart), label="drift")
    Box(Modifier.fillMaxSize()) {
        symbols.forEachIndexed { i, symbol ->
            val phase = (drift + i * 0.19f) % 1f
            Text(symbol, modifier=Modifier.align(Alignment.BottomEnd).offset(x=(-(18+i*57)).dp, y=(-(phase*760).dp)).alpha(0.025f + (1f-kotlin.math.abs(phase-0.5f)*2f)*0.035f), fontSize=(42+i*7).sp, color=MaterialTheme.colorScheme.primary)
        }
    }
}

@Composable
private fun HomeScreen(onGame:()->Unit, onCoach:()->Unit, onSettings:()->Unit) {
    Column(Modifier.fillMaxSize().padding(horizontal=28.dp), horizontalAlignment=Alignment.CenterHorizontally, verticalArrangement=Arrangement.Center) {
        Text("♞", fontSize=76.sp, color=MaterialTheme.colorScheme.primary)
        Spacer(Modifier.height(8.dp))
        Text("GlenMate", fontSize=36.sp, fontWeight=FontWeight.Bold, color=MaterialTheme.colorScheme.onBackground)
        Text("Твой шахматный помощник", fontSize=14.sp, color=MaterialTheme.colorScheme.onBackground.copy(alpha=.62f))
        Spacer(Modifier.height(48.dp))
        HomeButton("Игра", "Партия, доска и анализ", onGame)
        Spacer(Modifier.height(14.dp))
        HomeButton("Тренер", "Упражнения и обучение", onCoach)
        Spacer(Modifier.height(14.dp))
        HomeButton("Настройки", "Внешний вид и язык", onSettings, outlined=true)
        Spacer(Modifier.height(28.dp))
        Text("OFFLINE CHESS COMPANION", fontSize=10.sp, letterSpacing=2.sp, color=MaterialTheme.colorScheme.onBackground.copy(alpha=.35f))
    }
}

@Composable
private fun HomeButton(title:String, subtitle:String, onClick:()->Unit, outlined:Boolean=false) {
    Surface(onClick=onClick, modifier=Modifier.fillMaxWidth().height(76.dp), shape=RoundedCornerShape(20.dp), color=if(outlined) MaterialTheme.colorScheme.surface.copy(alpha=.72f) else MaterialTheme.colorScheme.primary.copy(alpha=.15f), border=androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha=if(outlined).45f else .18f))) {
        Row(Modifier.padding(horizontal=20.dp), verticalAlignment=Alignment.CenterVertically) {
            Column(Modifier.weight(1f), verticalArrangement=Arrangement.Center) {
                Text(title, fontSize=19.sp, fontWeight=FontWeight.SemiBold, color=MaterialTheme.colorScheme.onSurface)
                Text(subtitle, fontSize=12.sp, color=MaterialTheme.colorScheme.onSurface.copy(alpha=.58f))
            }
            Text("›", fontSize=30.sp, color=MaterialTheme.colorScheme.primary)
        }
    }
}

@Composable
private fun TopBar(title:String, onBack:()->Unit) {
    Row(Modifier.fillMaxWidth().padding(bottom=12.dp), verticalAlignment=Alignment.CenterVertically) {
        Text("‹", Modifier.clickable(onClick=onBack).padding(end=18.dp), fontSize=32.sp, color=MaterialTheme.colorScheme.primary)
        Text(title, fontSize=23.sp, fontWeight=FontWeight.Bold)
    }
}

@Composable
private fun SettingsScreen(onBack:()->Unit, dark:Boolean, onDark:(Boolean)->Unit, accentIndex:Int, onAccent:(Int)->Unit, language:String, onLanguage:(String)->Unit) {
    Column(Modifier.fillMaxSize().padding(20.dp)) {
        TopBar("Настройки", onBack)
        Row(Modifier.fillMaxWidth().padding(vertical=16.dp), verticalAlignment=Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) { Text("Тёмная тема", fontWeight=FontWeight.SemiBold); Text("Комфортный вид доски и меню", fontSize=12.sp, color=MaterialTheme.colorScheme.onSurface.copy(alpha=.6f)) }
            Switch(checked=dark, onCheckedChange=onDark)
        }
        Divider()
        Text("Цвет акцента", Modifier.padding(top=20.dp, bottom=12.dp), fontWeight=FontWeight.SemiBold)
        Row(horizontalArrangement=Arrangement.spacedBy(14.dp)) {
            listOf(Color(0xFF79C99E), Color(0xFF80B7FF), Color(0xFFC5A0FF), Color(0xFFFFB86B), Color(0xFFFF8F9B)).forEachIndexed { i,c ->
                Box(Modifier.size(38.dp).background(c, RoundedCornerShape(50)).clickable { onAccent(i) }, contentAlignment=Alignment.Center) { if(i==accentIndex) Text("✓", color=Color.Black, fontWeight=FontWeight.Bold) }
            }
        }
        Text("Язык", Modifier.padding(top=24.dp, bottom=8.dp), fontWeight=FontWeight.SemiBold)
        listOf("Русский", "English", "Deutsch", "Español", "Français", "Polski").forEach { item ->
            Row(Modifier.fillMaxWidth().clickable { onLanguage(item) }.padding(vertical=9.dp), verticalAlignment=Alignment.CenterVertically) {
                Text(item, Modifier.weight(1f)); RadioButton(selected=language==item, onClick={onLanguage(item)})
            }
        }
        Text("Выбор языка пока сохраняется только до закрытия приложения. Перевод всех экранов будет следующим этапом.", Modifier.padding(top=12.dp), fontSize=12.sp, color=MaterialTheme.colorScheme.onSurface.copy(alpha=.55f))
    }
}

@Composable
private fun CoachScreen(onBack:()->Unit, onOpenGame:()->Unit) {
    Column(Modifier.fillMaxSize().padding(20.dp)) {
        TopBar("Тренер", onBack)
        Spacer(Modifier.height(12.dp))
        Text("Тренируй шахматное мышление", fontSize=20.sp, fontWeight=FontWeight.SemiBold)
        Text("Раздел тренера будет расширяться. Сейчас можно открыть доску и проверить позицию движком Stockfish.", Modifier.padding(top=8.dp), color=MaterialTheme.colorScheme.onSurface.copy(alpha=.65f))
        Spacer(Modifier.height(24.dp))
        Button(onClick=onOpenGame, modifier=Modifier.fillMaxWidth()) { Text("Открыть анализ позиции") }
    }
}

@Composable
private fun GameScreen(onBack:()->Unit) {
    val context = androidx.compose.ui.platform.LocalContext.current
    val scope = rememberCoroutineScope()
    var fen by remember { mutableStateOf(ChessPosition.START_FEN) }
    var status by remember { mutableStateOf("Начальная позиция. Выбери клетки для ввода хода или расставь фигуры.") }
    var best by remember { mutableStateOf("—") }
    var evaluation by remember { mutableStateOf("—") }
    var pv by remember { mutableStateOf("") }
    var depth by remember { mutableIntStateOf(18) }
    var busy by remember { mutableStateOf(false) }
    var selected by remember { mutableStateOf<Int?>(null) }
    var editMode by remember { mutableStateOf(false) }
    var chosenPiece by remember { mutableStateOf('Q') }
    val pgnPicker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) runCatching { context.contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() } ?: error("Файл не открыт") }
            .onSuccess { text -> val parsed=PgnImporter.tryReadFenOrUci(text); if(parsed!=null){fen=parsed;status="Позиция из файла загружена."}else status="Не удалось разобрать файл: текущий импорт поддерживает FEN и UCI, не полную SAN-нотацию." }
            .onFailure { status="Ошибка чтения: ${it.message}" }
    }
    Column(Modifier.fillMaxSize().padding(horizontal=16.dp)) {
        TopBar("Игра и анализ", onBack)
        LazyColumn(verticalArrangement=Arrangement.spacedBy(10.dp), contentPadding=PaddingValues(bottom=24.dp)) {
            item { ChessBoard(fen, selected, onSquare={ index ->
                if(editMode){ val cells=ChessPosition.boardChars(fen).toMutableList(); cells[index]=chosenPiece; fen=ChessPosition.withBoard(fen,cells) }
                else if(selected==null) selected=index else { val from=ChessPosition.squareName(selected!!); val to=ChessPosition.squareName(index); val updated=ChessPosition.applyUci(fen,from+to); if(updated!=null){fen=updated;status="Ход $from$to внесён. Легальность пока не проверяется."}else status="Не удалось применить ход."; selected=null }
            }) }
            item { Row(verticalAlignment=Alignment.CenterVertically) { Switch(checked=editMode,onCheckedChange={editMode=it;selected=null}); Spacer(Modifier.width(8.dp)); Text("Расстановка фигур") } }
            if(editMode) item { Row(horizontalArrangement=Arrangement.spacedBy(1.dp)) { listOf('K','Q','R','B','N','P','k','q','r','b','n','p','.').forEach { p -> TextButton(onClick={chosenPiece=p}) { Text(if(p=='.')"⌫" else ChessPosition.glyph(p), color=if(chosenPiece==p) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface) } } } }
            item { OutlinedTextField(value=fen,onValueChange={fen=it},label={Text("FEN позиции")},modifier=Modifier.fillMaxWidth(),minLines=2) }
            item { Row(horizontalArrangement=Arrangement.spacedBy(8.dp)) { OutlinedButton(onClick={pgnPicker.launch("*/*")},modifier=Modifier.weight(1f)){Text("Импорт PGN")}; OutlinedButton(onClick={fen=ChessPosition.START_FEN;status="Начальная позиция."},modifier=Modifier.weight(1f)){Text("Сбросить") } } }
            item { Text("Глубина анализа: $depth"); Slider(value=depth.toFloat(),onValueChange={depth=it.toInt()},valueRange=10f..30f,steps=19) }
            item { Button(onClick={busy=true;status="Анализ выполняется…";scope.launch{val result=withContext(Dispatchers.IO){StockfishEngine(context).analyze(fen,depth)};best=result.bestMove;evaluation=result.evaluation;pv=result.pv;status=result.message;busy=false}},enabled=!busy&&ChessPosition.isPlausibleFen(fen),modifier=Modifier.fillMaxWidth()){Text(if(busy)"Анализ…" else "Найти лучший ход Stockfish")} }
            item { Card { Column(Modifier.padding(14.dp),verticalArrangement=Arrangement.spacedBy(6.dp)){Text("РЕЗУЛЬТАТ АНАЛИЗА",fontWeight=FontWeight.Bold,color=MaterialTheme.colorScheme.primary);Text("Лучший ход: $best",fontSize=20.sp,fontWeight=FontWeight.Bold);Text("Оценка: $evaluation");if(pv.isNotBlank())Text("Вариант: $pv");Text(status,fontSize=12.sp,color=MaterialTheme.colorScheme.onSurface.copy(alpha=.65f))} } }
        }
    }
}

@Composable
fun ChessBoard(fen:String, selected:Int?, onSquare:(Int)->Unit) {
    val cells=remember(fen){ChessPosition.boardChars(fen)}
    Column(Modifier.fillMaxWidth().aspectRatio(1f)) { for(r in 0..7) Row(Modifier.weight(1f)){ for(c in 0..7){val i=r*8+c;val light=Color(0xFFE8DCC4);val dark=Color(0xFF77966D);val color=if(selected==i)Color(0xFFE8D36A)else if((r+c)%2==0)light else dark;Box(Modifier.weight(1f).fillMaxHeight().background(color).clickable{onSquare(i)},contentAlignment=Alignment.Center){val piece=cells.getOrElse(i){'.'};Text(if(piece=='.')"" else ChessPosition.glyph(piece),fontSize=30.sp,color=if(piece.isUpperCase())Color(0xFFF8F5EA)else Color(0xFF172019))}}} }
}

data class EngineResult(val bestMove: String, val evaluation: String, val pv: String, val message: String)

class StockfishEngine(private val context: android.content.Context) {
    fun analyze(fen: String, depth: Int): EngineResult = try {
        val abi = android.os.Build.SUPPORTED_ABIS.firstOrNull() ?: "unknown"
        val target = java.io.File(context.filesDir, "stockfish")
        context.assets.open("stockfish/$abi/stockfish").use { input -> target.outputStream().use { input.copyTo(it) } }
        target.setExecutable(true)
        val process = ProcessBuilder(target.absolutePath).redirectErrorStream(true).start()
        val writer = process.outputStream.bufferedWriter()
        val reader = process.inputStream.bufferedReader()
        fun send(s: String) { writer.write(s); writer.newLine(); writer.flush() }
        send("uci")
        var line: String?
        var ready = false
        while (true) { line = reader.readLine() ?: break; if (line == "uciok") { ready = true; break } }
        if (!ready) error("Stockfish не ответил на UCI")
        send("isready")
        while (reader.readLine()?.trim() != "readyok") { }
        send("position fen $fen"); send("go depth $depth")
        var best = "—"; var score = "—"; var variation = ""
        while (true) {
            line = reader.readLine() ?: break
            if (line!!.startsWith("info ") && line!!.contains(" score ")) {
                val t = line!!.split(" "); val si = t.indexOf("score")
                if (si >= 0 && si+2 < t.size) score = when(t[si+1]) {
                    "cp" -> "%+.2f пешки".format(java.util.Locale.US, t[si+2].toInt()/100.0)
                    "mate" -> "мат в ${t[si+2]}"
                    else -> score
                }
                val pi = t.indexOf("pv"); if (pi >= 0) variation = t.drop(pi+1).take(12).joinToString(" ")
            }
            if (line!!.startsWith("bestmove ")) { best = line!!.split(" ").getOrNull(1) ?: "—"; break }
        }
        send("quit"); process.waitFor()
        EngineResult(best, score, variation, "Анализ завершён на глубине $depth.")
    } catch (e: Exception) {
        EngineResult("—", "—", "", "Stockfish не найден или не запустился: ${e.message}. Добавьте бинарник для ABI устройства.")
    }
}

object ChessPosition {
    const val START_FEN = "rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1"
    fun boardChars(fen: String): List<Char> {
        val ranks = fen.trim().substringBefore(' ').split('/')
        if (ranks.size != 8) return List(64) { '.' }
        val out = mutableListOf<Char>()
        ranks.forEach { rank -> rank.forEach { ch -> if (ch.isDigit()) repeat(ch.digitToInt()) { out.add('.') } else out.add(ch) } }
        return if (out.size == 64) out else List(64) { '.' }
    }
    fun squareName(i: Int) = "${'a' + i%8}${8-i/8}"
    fun glyph(p: Char) = when(p) {
        'K'->"♔"; 'Q'->"♕"; 'R'->"♖"; 'B'->"♗"; 'N'->"♘"; 'P'->"♙"
        'k'->"♚"; 'q'->"♛"; 'r'->"♜"; 'b'->"♝"; 'n'->"♞"; 'p'->"♟"; else->""
    }
    fun isPlausibleFen(fen: String): Boolean {
        val p = fen.trim().split(Regex("\\s+")); if (p.size != 6 || p[1] !in listOf("w","b")) return false
        val ranks = p[0].split('/'); if (ranks.size != 8) return false
        return ranks.all { rank -> var n=0; for(ch in rank) { if(ch.isDigit()) n+=ch.digitToInt() else if(ch in "KQRBNPkqrbnp") n++ else return@all false }; n==8 }
    }
    fun withBoard(fen: String, cells: List<Char>): String {
        val board = (0..7).joinToString("/") { r ->
            val s=StringBuilder(); var empty=0
            cells.subList(r*8,r*8+8).forEach { if(it=='.') empty++ else { if(empty>0)s.append(empty); empty=0; s.append(it) } }
            if(empty>0)s.append(empty); s.toString()
        }
        val p=fen.trim().split(Regex("\\s+")); val tail=if(p.size>=6)p.drop(1).joinToString(" ") else "w - - 0 1"
        return "$board $tail"
    }
    fun applyUci(fen: String, uci: String): String? {
        if(uci.length !in 4..5) return null
        fun idx(s:String):Int { if(s.length!=2 || s[0] !in 'a'..'h' || s[1] !in '1'..'8')return -1; return (8-(s[1]-'0'))*8+(s[0]-'a') }
        val a=idx(uci.substring(0,2)); val b=idx(uci.substring(2,4)); if(a !in 0..63 || b !in 0..63)return null
        val cells=boardChars(fen).toMutableList(); if(cells[a]=='.')return null
        var piece=cells[a]; if(uci.length==5)piece=if(piece.isUpperCase())uci[4].uppercaseChar() else uci[4]
        cells[a]='.'; cells[b]=piece
        val p=fen.trim().split(Regex("\\s+")); val side=if(p.getOrNull(1)=="w")"b" else "w"
        return withBoard(fen,cells).substringBefore(' ') + " $side ${p.getOrNull(2) ?: "-"} - 0 1"
    }
}

object PgnImporter {
    fun tryReadFenOrUci(pgn: String): String? {
        val fen = Regex("""(?m)^\[FEN\s+"([^"]+)"\]""").find(pgn)?.groupValues?.get(1)
        if(fen != null)return fen.takeIf { ChessPosition.isPlausibleFen(it) }
        val body=pgn.lines().filterNot { it.trim().startsWith("[") }.joinToString(" ")
            .replace(Regex("\\{[^}]*}")," ").replace(Regex("\\([^)]*\\)")," ")
        val moves=body.split(Regex("\\s+")).filter { it.isNotBlank() }
            .filterNot { it.matches(Regex("\\d+\\.{1,3}")) || it in listOf("1-0","0-1","1/2-1/2","*") }
        if(moves.isEmpty() || moves.any { !it.matches(Regex("[a-h][1-8][a-h][1-8][qrbnQRBN]?")) })return null
        var result=ChessPosition.START_FEN
        moves.forEach { result=ChessPosition.applyUci(result,it) ?: return null }
        return result
    }
}
