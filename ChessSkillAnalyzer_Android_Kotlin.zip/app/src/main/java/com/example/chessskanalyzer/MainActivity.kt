package com.example.chessskanalyzer

import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { GlenMateApp() }
    }
}

private enum class Page { HOME, GAME, COACH, SETTINGS }

@Composable
fun GlenMateApp() {
    var page by remember { mutableStateOf(Page.HOME) }
    var dark by remember { mutableStateOf(true) }
    var accentIndex by remember { mutableIntStateOf(0) }
    var language by remember { mutableStateOf("Русский") }
    var textIndex by remember { mutableIntStateOf(0) }
    var backgroundIndex by remember { mutableIntStateOf(0) }
    var buttonIndex by remember { mutableIntStateOf(0) }
    var boardThemeIndex by remember { mutableIntStateOf(0) }
    var boardSizeIndex by remember { mutableIntStateOf(1) }
    val accents = listOf(Color(0xFF79C99E), Color(0xFF80B7FF), Color(0xFFC5A0FF), Color(0xFFFFB86B), Color(0xFFFF8F9B))
    val textColors = listOf(Color(0xFFF0F4F0), Color(0xFFE8DCC4), Color(0xFFB9D7FF), Color(0xFFFFE2B8), Color(0xFF20252B))
    val darkBackgrounds = listOf(Color(0xFF101713), Color(0xFF101820), Color(0xFF17151D), Color(0xFF201912), Color(0xFF202326))
    val lightBackgrounds = listOf(Color(0xFFF4F6F2), Color(0xFFEAF0F5), Color(0xFFF1EDF5), Color(0xFFF7F0E7), Color(0xFFECEEEF))
    val buttonColors = listOf(Color(0xFF79C99E), Color(0xFF80B7FF), Color(0xFFC5A0FF), Color(0xFFFFB86B), Color(0xFFFF8F9B))
    val accent = accents[accentIndex]
    val bg = (if (dark) darkBackgrounds else lightBackgrounds)[backgroundIndex]
    val fg = if (dark) textColors[textIndex].let { if (it == Color(0xFF20252B)) Color(0xFFF0F4F0) else it } else listOf(Color(0xFF172019), Color(0xFF34404A), Color(0xFF3D3150), Color(0xFF493A2B), Color(0xFF20252B))[textIndex]
    val btn = buttonColors[buttonIndex]
    val boardThemes = listOf(Color(0xFFE6E0D3) to Color(0xFF617F76), Color(0xFFE8D7B5) to Color(0xFF8B654A), Color(0xFFE8EDF2) to Color(0xFF647C99), Color(0xFFF0E2EA) to Color(0xFF92748A))
    val boardScale = listOf(.88f,.94f,1.0f)[boardSizeIndex]
    val scheme = if (dark) darkColorScheme(primary=accent, background=bg, surface=bg.copy(red=(bg.red*0.92f).coerceIn(0f,1f), green=(bg.green*0.92f).coerceIn(0f,1f), blue=(bg.blue*0.92f).coerceIn(0f,1f)), onBackground=fg, onSurface=fg)
                else lightColorScheme(primary=accent, background=bg, surface=Color.White, onBackground=fg, onSurface=fg)
    MaterialTheme(colorScheme=scheme) {
        CompositionLocalProvider(LocalGlenText provides fg, LocalGlenButton provides btn, LocalBoardLight provides boardThemes[boardThemeIndex].first, LocalBoardDark provides boardThemes[boardThemeIndex].second, LocalBoardScale provides boardScale) {
            Box(Modifier.fillMaxSize().background(bg)) {
                FloatingChessBackground()
                when(page) {
                    Page.HOME -> HomeScreen(onGame={page=Page.GAME}, onCoach={page=Page.COACH}, onSettings={page=Page.SETTINGS})
                    Page.GAME -> GameScreen(onBack={page=Page.HOME})
                    Page.COACH -> CoachScreen(onBack={page=Page.HOME}, onOpenGame={page=Page.GAME})
                    Page.SETTINGS -> SettingsScreen(onBack={page=Page.HOME}, dark=dark, onDark={dark=it}, accentIndex=accentIndex, onAccent={accentIndex=it}, language=language, onLanguage={language=it}, textIndex=textIndex, onText={textIndex=it}, backgroundIndex=backgroundIndex, onBackground={backgroundIndex=it}, buttonIndex=buttonIndex, onButton={buttonIndex=it}, boardThemeIndex=boardThemeIndex, onBoardTheme={boardThemeIndex=it}, boardSizeIndex=boardSizeIndex, onBoardSize={boardSizeIndex=it})
                }
            }
        }
    }
}

private val LocalGlenText = compositionLocalOf { Color.White }
private val LocalGlenButton = compositionLocalOf { Color(0xFF79C99E) }
private val LocalBoardLight = compositionLocalOf { Color(0xFFE6E0D3) }
private val LocalBoardDark = compositionLocalOf { Color(0xFF617F76) }
private val LocalBoardScale = compositionLocalOf { 1f }

@Composable
private fun FloatingChessBackground() {
    val symbols = listOf("♘", "♗", "♙", "♖", "♕")
    val transition = rememberInfiniteTransition(label="floating-pieces")
    val drift by transition.animateFloat(initialValue=0f, targetValue=1f, animationSpec=infiniteRepeatable(tween(18000, easing=LinearEasing), RepeatMode.Restart), label="drift")
    Box(Modifier.fillMaxSize()) {
        symbols.forEachIndexed { i, symbol ->
            val phase = (drift + i * 0.19f) % 1f
            Text(symbol, modifier=Modifier.align(Alignment.BottomEnd).offset(x=(-(18+i*57)).dp, y=(-(phase*760).dp)).alpha(0.025f + (1f-kotlin.math.abs(phase-0.5f)*2f)*0.035f), fontSize=(42+i*7).sp, color=MaterialTheme.colorScheme.primary)
        }
    }
}

@Composable
private fun HomeScreen(onGame:()->Unit, onCoach:()->Unit, onSettings:()->Unit) {
    Column(Modifier.fillMaxSize().padding(horizontal=28.dp), horizontalAlignment=Alignment.CenterHorizontally, verticalArrangement=Arrangement.Center) {
        Text("♞", fontSize=76.sp, color=MaterialTheme.colorScheme.primary)
        Spacer(Modifier.height(8.dp))
        Text("GlenMate", fontSize=36.sp, fontWeight=FontWeight.Bold, color=MaterialTheme.colorScheme.onBackground)
        Text("Твой шахматный помощник", fontSize=14.sp, color=MaterialTheme.colorScheme.onBackground.copy(alpha=.62f))
        Spacer(Modifier.height(48.dp))
        HomeButton("Игра", "Партия, доска и анализ", onGame)
        Spacer(Modifier.height(14.dp))
        HomeButton("Тренер", "Упражнения и обучение", onCoach)
        Spacer(Modifier.height(14.dp))
        HomeButton("Настройки", "Внешний вид и язык", onSettings, outlined=true)
        Spacer(Modifier.height(28.dp))
        Text("OFFLINE CHESS COMPANION", fontSize=10.sp, letterSpacing=2.sp, color=MaterialTheme.colorScheme.onBackground.copy(alpha=.35f))
    }
}

@Composable
private fun HomeButton(title:String, subtitle:String, onClick:()->Unit, outlined:Boolean=false) {
    Surface(onClick=onClick, modifier=Modifier.fillMaxWidth().height(76.dp), shape=RoundedCornerShape(8.dp), color=if(outlined) MaterialTheme.colorScheme.surface.copy(alpha=.72f) else MaterialTheme.colorScheme.primary.copy(alpha=.15f), border=androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha=if(outlined).45f else .18f))) {
        Row(Modifier.padding(horizontal=20.dp), verticalAlignment=Alignment.CenterVertically) {
            Column(Modifier.weight(1f), verticalArrangement=Arrangement.Center) {
                Text(title, fontSize=19.sp, fontWeight=FontWeight.SemiBold, color=MaterialTheme.colorScheme.onSurface)
                Text(subtitle, fontSize=12.sp, color=MaterialTheme.colorScheme.onSurface.copy(alpha=.58f))
            }
            Text("›", fontSize=30.sp, color=MaterialTheme.colorScheme.primary)
        }
    }
}

@Composable
private fun TopBar(title:String, onBack:()->Unit) {
    Row(Modifier.fillMaxWidth().padding(bottom=12.dp), verticalAlignment=Alignment.CenterVertically) {
        Text("‹", Modifier.clickable(onClick=onBack).padding(end=18.dp), fontSize=32.sp, color=MaterialTheme.colorScheme.primary)
        Text(title, fontSize=23.sp, fontWeight=FontWeight.Bold)
    }
}

@Composable
private fun SettingsScreen(onBack:()->Unit, dark:Boolean, onDark:(Boolean)->Unit, accentIndex:Int, onAccent:(Int)->Unit, language:String, onLanguage:(String)->Unit, textIndex:Int, onText:(Int)->Unit, backgroundIndex:Int, onBackground:(Int)->Unit, buttonIndex:Int, onButton:(Int)->Unit, boardThemeIndex:Int, onBoardTheme:(Int)->Unit, boardSizeIndex:Int, onBoardSize:(Int)->Unit) {
    val swatches = listOf(Color(0xFF79C99E), Color(0xFF80B7FF), Color(0xFFC5A0FF), Color(0xFFFFB86B), Color(0xFFFF8F9B))
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp)) {
        TopBar("Настройки", onBack)
        Row(Modifier.fillMaxWidth().padding(vertical=12.dp), verticalAlignment=Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) { Text("Тёмная тема", fontWeight=FontWeight.SemiBold); Text("Базовый режим оформления", fontSize=12.sp, color=MaterialTheme.colorScheme.onSurface.copy(alpha=.6f)) }
            Switch(checked=dark, onCheckedChange=onDark)
        }
        HorizontalDivider()
        PaletteRow("Цвет текста", textIndex, onText, listOf(Color(0xFFF0F4F0), Color(0xFFE8DCC4), Color(0xFFB9D7FF), Color(0xFFFFE2B8), Color(0xFF20252B)))
        PaletteRow("Цвет фона", backgroundIndex, onBackground, if(dark) listOf(Color(0xFF101713), Color(0xFF101820), Color(0xFF17151D), Color(0xFF201912), Color(0xFF202326)) else listOf(Color(0xFFF4F6F2), Color(0xFFEAF0F5), Color(0xFFF1EDF5), Color(0xFFF7F0E7), Color(0xFFECEEEF)))
        PaletteRow("Цвет кнопок", buttonIndex, onButton, swatches)
        PaletteRow("Оформление доски", boardThemeIndex, onBoardTheme, listOf(Color(0xFFE6E0D3),Color(0xFFE8D7B5),Color(0xFFE8EDF2),Color(0xFFF0E2EA)))
        Text("Размер доски",Modifier.padding(top=12.dp),fontWeight=FontWeight.SemiBold,fontSize=14.sp)
        Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(8.dp)) { listOf("Компактный","Средний","Большой").forEachIndexed{i,label->FilterChip(selected=boardSizeIndex==i,onClick={onBoardSize(i)},label={Text(label,fontSize=11.sp)})} }
        PaletteRow("Цвет акцента", accentIndex, onAccent, swatches)
        Text("Язык", Modifier.padding(top=14.dp, bottom=4.dp), fontWeight=FontWeight.SemiBold)
        listOf("Русский", "English", "Deutsch", "Español", "Français", "Polski").forEach { item ->
            Row(Modifier.fillMaxWidth().clickable { onLanguage(item) }.padding(vertical=5.dp), verticalAlignment=Alignment.CenterVertically) {
                Text(item, Modifier.weight(1f)); RadioButton(selected=language==item, onClick={onLanguage(item)})
            }
        }
        Text("Переводы экранов подключаются отдельно; выбор языка пока не переводит весь интерфейс.", Modifier.padding(top=6.dp), fontSize=11.sp, color=MaterialTheme.colorScheme.onSurface.copy(alpha=.55f))
    }
}

@Composable
private fun PaletteRow(title:String, selected:Int, onSelected:(Int)->Unit, colors:List<Color>) {
    Column(Modifier.fillMaxWidth().padding(top=12.dp)) {
        Text(title, fontWeight=FontWeight.SemiBold, fontSize=14.sp)
        Row(Modifier.padding(top=7.dp), horizontalArrangement=Arrangement.spacedBy(12.dp)) {
            colors.forEachIndexed { i, color ->
                Box(Modifier.size(34.dp).background(color, RoundedCornerShape(7.dp)).clickable { onSelected(i) }, contentAlignment=Alignment.Center) {
                    if (selected==i) Text("✓", color=if(color.luminance()>.5f) Color.Black else Color.White, fontWeight=FontWeight.Bold)
                }
            }
        }
    }
}

@Composable
private fun CoachScreen(onBack:()->Unit, onOpenGame:()->Unit) {
    val context=androidx.compose.ui.platform.LocalContext.current
    val prefs=remember { context.getSharedPreferences("glenmate_training", android.content.Context.MODE_PRIVATE) }
    var mode by remember { mutableStateOf("Тактика") }
    val puzzles=listOf(
        Triple("7k/5Q2/6K1/8/8/8/8/8 w - - 0 1","f7g7","Ферзь ставит мат на g7."),
        Triple("7k/8/5KQ1/8/8/8/8/8 w - - 0 1","g6g7","Ферзь входит на g7 под защитой короля."),
        Triple("8/8/8/8/8/6k1/5q2/7K b - - 0 1","f2g2","Чёрные ставят мат ходом ферзя на g2.")
    )
    var puzzleIndex by remember { mutableIntStateOf(0) }
    val puzzleFen=puzzles[puzzleIndex].first
    var fen by remember { mutableStateOf(puzzleFen) }
    var selected by remember { mutableStateOf<Int?>(null) }
    var message by remember { mutableStateOf("Белые начинают. Найди мат в один ход.") }
    var solved by remember { mutableStateOf(false) }
    var hint by remember { mutableStateOf(false) }
    var attempts by remember { mutableIntStateOf(prefs.getInt("attempts",0)) }
    var solvedCount by remember { mutableIntStateOf(prefs.getInt("solved",0)) }
    val targets = selected?.let { ChessPosition.legalTargets(fen,it) } ?: emptySet()
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        TopBar("Тренер", onBack)
        Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(6.dp)) {
            listOf("Тактика","Дебюты","Статистика").forEach { tab ->
                val active=mode==tab
                TextButton(onClick={mode=tab},modifier=Modifier.weight(1f),contentPadding=PaddingValues(horizontal=2.dp)) {
                    Text(tab,fontSize=12.sp,fontWeight=if(active)FontWeight.Bold else FontWeight.Normal,color=if(active)MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface)
                }
            }
        }
        when(mode) {
            "Тактика" -> {
                Text("Мат в один ход",fontSize=20.sp,fontWeight=FontWeight.Bold)
                Text("Задача ${puzzleIndex+1} из ${puzzles.size} · Начальный уровень",fontSize=12.sp,color=MaterialTheme.colorScheme.onSurface.copy(alpha=.6f))
                Box(Modifier.fillMaxWidth().weight(1f),contentAlignment=Alignment.Center) {
                    BoxWithConstraints(Modifier.fillMaxSize()) {
                        val size=minOf(maxWidth,maxHeight) * LocalBoardScale.current
                        Box(Modifier.size(size)) {
                            ChessBoard(fen,selected,targets,null,ChessPosition.checkKingSquare(fen),"—") { index ->
                                if(solved) return@ChessBoard
                                if(selected==null) { val p=ChessPosition.boardChars(fen)[index]; val whiteToMove=fen.split(" ").getOrNull(1)!="b"; if(p!='.' && p.isUpperCase()==whiteToMove) selected=index }
                                else if(index==selected) selected=null
                                else {
                                    val from=ChessPosition.squareName(selected!!); val to=ChessPosition.squareName(index)
                                    val next=ChessPosition.applyUci(fen,from+to)
                                    attempts++; prefs.edit().putInt("attempts",attempts).apply()
                                    if(next!=null && from+to==puzzles[puzzleIndex].second && ChessPosition.isCheckmate(next)) {
                                        fen=next; solved=true; solvedCount++; prefs.edit().putInt("solved",solvedCount).apply(); message="Верно! Мат поставлен."
                                    } else {
                                        message=if(next==null) "Нелегальный ход. Попробуй ещё раз." else "Ход возможен, но это не мат. Попробуй ещё раз."
                                        fen=puzzleFen
                                    }
                                    selected=null
                                }
                            }
                        }
                    }
                }
                Text(message,Modifier.fillMaxWidth().padding(vertical=6.dp),fontWeight=FontWeight.SemiBold,fontSize=13.sp)
                if(hint&&!solved) Text("Подсказка: ${puzzles[puzzleIndex].third}",fontSize=12.sp,color=MaterialTheme.colorScheme.primary)
                Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick={hint=true},modifier=Modifier.weight(1f),enabled=!solved){Text("Подсказка")}
                    Button(onClick={if(solved) puzzleIndex=(puzzleIndex+1)%puzzles.size;fen=puzzles[puzzleIndex].first;selected=null;solved=false;hint=false;message=if(fen.split(" ").getOrNull(1)=="b")"Чёрные начинают. Найди мат в один ход." else "Белые начинают. Найди мат в один ход."},modifier=Modifier.weight(1f)){Text(if(solved)"Следующая" else "Повторить")}
                }
            }
            "Дебюты" -> {
                Text("Справочник дебютов",fontSize=20.sp,fontWeight=FontWeight.Bold)
                Text("Краткие ориентиры для начала партии",fontSize=12.sp,color=MaterialTheme.colorScheme.onSurface.copy(alpha=.6f))
                LazyColumn(Modifier.weight(1f),verticalArrangement=Arrangement.spacedBy(8.dp)) {
                    val openings=listOf(
                        Triple("Итальянская партия","1. e4 e5 2. Nf3 Nc6 3. Bc4","Развитие фигур и давление на поле f7."),
                        Triple("Испанская партия","1. e4 e5 2. Nf3 Nc6 3. Bb5","Давление на коня c6 и контроль центра."),
                        Triple("Сицилианская защита","1. e4 c5","Асимметричная борьба за центр."),
                        Triple("Французская защита","1. e4 e6","Подготовка ...d5 и борьба за центр."),
                        Triple("Защита Каро—Канн","1. e4 c6 2. d4 d5","Прочная центральная структура."),
                        Triple("Ферзевый гамбит","1. d4 d5 2. c4","Борьба за центральные поля d4 и e4.")
                    )
                    items(openings.size){i->val item=openings[i];Card { Column(Modifier.padding(12.dp)) { Text(item.first,fontWeight=FontWeight.Bold);Text(item.second,color=MaterialTheme.colorScheme.primary,fontSize=13.sp);Text(item.third,fontSize=12.sp,color=MaterialTheme.colorScheme.onSurface.copy(alpha=.7f)) } }}
                }
            }
            else -> {
                Text("Статистика тренировок",fontSize=20.sp,fontWeight=FontWeight.Bold)
                Spacer(Modifier.height(14.dp))
                Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(10.dp)) {
                    Card(Modifier.weight(1f)){Column(Modifier.padding(14.dp)){Text("Попытки",fontSize=12.sp);Text("$attempts",fontSize=28.sp,fontWeight=FontWeight.Bold)}}
                    Card(Modifier.weight(1f)){Column(Modifier.padding(14.dp)){Text("Решено",fontSize=12.sp);Text("$solvedCount",fontSize=28.sp,fontWeight=FontWeight.Bold)}}
                }
                val gameCount=prefs.getInt("games",0); val whiteWins=prefs.getInt("wins_white",0); val blackWins=prefs.getInt("wins_black",0); val draws=prefs.getInt("draws",0)
                Text("Партии",Modifier.padding(top=18.dp,bottom=8.dp),fontWeight=FontWeight.Bold,fontSize=16.sp)
                Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(8.dp)) {
                    Card(Modifier.weight(1f)){Column(Modifier.padding(10.dp)){Text("Завершено",fontSize=11.sp);Text("$gameCount",fontSize=23.sp,fontWeight=FontWeight.Bold)}}
                    Card(Modifier.weight(1f)){Column(Modifier.padding(10.dp)){Text("Ничьи",fontSize=11.sp);Text("$draws",fontSize=23.sp,fontWeight=FontWeight.Bold)}}
                }
                Text("Победы белых: $whiteWins · чёрных: $blackWins",Modifier.padding(top=8.dp),fontSize=12.sp)
                Text("Результаты записываются, когда партия на доске заканчивается матом или патом.",Modifier.padding(top=8.dp),fontSize=11.sp,color=MaterialTheme.colorScheme.onSurface.copy(alpha=.65f))
                Spacer(Modifier.weight(1f))
            }
        }
        TextButton(onClick=onOpenGame,modifier=Modifier.align(Alignment.CenterHorizontally)){Text("Открыть анализ Stockfish")}
    }
}

@Composable
private fun GameScreen(onBack:()->Unit) {
    val context = androidx.compose.ui.platform.LocalContext.current
    val scope = rememberCoroutineScope()
    var fen by remember { mutableStateOf(ChessPosition.START_FEN) }
    var status by remember { mutableStateOf("Начальная позиция") }
    var best by remember { mutableStateOf("—") }
    var evaluation by remember { mutableStateOf("—") }
    var depth by remember { mutableIntStateOf(18) }
    var busy by remember { mutableStateOf(false) }
    var selected by remember { mutableStateOf<Int?>(null) }
    var lastMove by remember { mutableStateOf<String?>(null) }
    val moveHistory = remember { mutableStateListOf<String>() }
    val movePositions = remember { mutableStateListOf(ChessPosition.START_FEN) }
    val moveEvaluations = remember { mutableStateListOf("—") }
    var currentHistoryIndex by remember { mutableIntStateOf(0) }
    val pgnMoves = remember { mutableStateListOf<String>() }
    var initialFen by remember { mutableStateOf(ChessPosition.START_FEN) }
    var editMode by remember { mutableStateOf(false) }
    var chosenPiece by remember { mutableStateOf('Q') }
    var showFen by remember { mutableStateOf(false) }
    var showImport by remember { mutableStateOf(false) }
    val pgnPicker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) runCatching { context.contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() } ?: error("Файл не открыт") }
            .onSuccess { text ->
                val parsed=PgnImporter.parseGame(text)
                if(parsed!=null){
                    fen=parsed.finalFen;initialFen=parsed.initialFen;pgnMoves.clear();pgnMoves.addAll(parsed.moves)
                    moveHistory.clear();moveHistory.addAll(parsed.moves.mapIndexed{i,m->"${i/2+1}${if(i%2==0)"." else "..."} ${m.substring(0,2)}–${m.substring(2,4)}"})
                    movePositions.clear();movePositions.add(parsed.initialFen);var cursor=parsed.initialFen;parsed.moves.forEach{cursor=ChessPosition.applyUci(cursor,it)?:cursor;movePositions.add(cursor)}
                    moveEvaluations.clear();repeat(movePositions.size){moveEvaluations.add("—")};currentHistoryIndex=movePositions.lastIndex
                    lastMove=parsed.moves.lastOrNull();best="—";evaluation="—";status="PGN загружен: ${parsed.moves.size} ходов"
                }
                else status="Не удалось разобрать PGN"
            }.onFailure { status="Ошибка чтения файла" }
    }
    val pgnSaver = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/x-chess-pgn")) { uri ->
        if(uri!=null) runCatching { context.contentResolver.openOutputStream(uri)?.bufferedWriter()?.use { it.write(PgnExporter.export(initialFen,pgnMoves)) } ?: error("Файл не создан") }
            .onSuccess { status="PGN сохранён" }.onFailure { status="Ошибка экспорта PGN" }
    }
    Column(Modifier.fillMaxSize().padding(horizontal=12.dp, vertical=6.dp)) {
        TopBar("Игра", onBack)
        BoxWithConstraints(Modifier.fillMaxWidth().weight(1f)) {
            val boardSize = minOf(maxWidth, maxHeight * .48f) * LocalBoardScale.current
            Column(Modifier.fillMaxSize(), horizontalAlignment=Alignment.CenterHorizontally) {
                Box(Modifier.size(boardSize)) {
                    val legalTargets = selected?.let { ChessPosition.legalTargets(fen, it) } ?: emptySet()
                    ChessBoard(fen, selected, legalTargets, lastMove, ChessPosition.checkKingSquare(fen), best, onSquare={ index ->
                        if(editMode){ val cells=ChessPosition.boardChars(fen).toMutableList(); cells[index]=chosenPiece; fen=ChessPosition.withBoard(fen,cells); selected=null }
                        else if(selected==null) {
                            val piece=ChessPosition.boardChars(fen)[index]
                            val whiteToMove=fen.trim().split(Regex("\\s+" )).getOrNull(1)!="b"
                            if(piece!='.' && piece.isUpperCase()==whiteToMove) selected=index
                        } else if(index==selected) {
                            selected=null
                        } else {
                            val cells=ChessPosition.boardChars(fen); val moving=cells[selected!!]
                            val from=ChessPosition.squareName(selected!!); val to=ChessPosition.squareName(index)
                            val promotion=if(moving.lowercaseChar()=='p' && (to.endsWith("8")||to.endsWith("1"))) "q" else ""
                            val uci=from+to+promotion
                            val updated=ChessPosition.applyUci(fen,uci)
                            if(updated!=null){
                                if(currentHistoryIndex<pgnMoves.size) {
                                    while(pgnMoves.size>currentHistoryIndex) pgnMoves.removeAt(pgnMoves.lastIndex)
                                    while(moveHistory.size>currentHistoryIndex) moveHistory.removeAt(moveHistory.lastIndex)
                                    while(movePositions.size>currentHistoryIndex+1) movePositions.removeAt(movePositions.lastIndex)
                                    while(moveEvaluations.size>currentHistoryIndex+1) moveEvaluations.removeAt(moveEvaluations.lastIndex)
                                }
                                fen=updated;lastMove=uci;pgnMoves.add(uci);moveHistory.add("${moveHistory.size+1}. $from–$to");movePositions.add(updated);moveEvaluations.add("—");currentHistoryIndex=movePositions.lastIndex;best="—";evaluation="—";selected=null
                                if(ChessPosition.isCheckmate(updated)) {
                                    val winner=if(updated.split(" ").getOrNull(1)=="w") "black" else "white"
                                    val games=context.getSharedPreferences("glenmate_training",android.content.Context.MODE_PRIVATE)
                                    games.edit().putInt("games",games.getInt("games",0)+1).putInt("wins_$winner",games.getInt("wins_$winner",0)+1).apply()
                                    status="Мат! Победа ${if(winner=="white")"белых" else "чёрных"}"
                                } else if(ChessPosition.isStalemate(updated)) {
                                    val games=context.getSharedPreferences("glenmate_training",android.content.Context.MODE_PRIVATE);games.edit().putInt("games",games.getInt("games",0)+1).putInt("draws",games.getInt("draws",0)+1).apply();status="Пат. Ничья"
                                } else status=if(ChessPosition.isInCheck(updated)) "Шах" else "Легальный ход $from–$to"
                            }
                            else if(cells[index]!='.' && cells[index].isUpperCase()==moving.isUpperCase()) { selected=index }
                            else { status="Нелегальный ход: проверь правила шахмат"; selected=null }
                        }
                    })
                }
                Spacer(Modifier.height(8.dp))
                if(moveHistory.isNotEmpty()) Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),horizontalArrangement=Arrangement.spacedBy(4.dp)) {
                    moveHistory.forEachIndexed { i,label -> TextButton(onClick={currentHistoryIndex=i+1;fen=movePositions.getOrElse(i+1){fen};lastMove=pgnMoves.getOrNull(i);evaluation=moveEvaluations.getOrElse(i+1){"—"};best="—";selected=null},contentPadding=PaddingValues(horizontal=6.dp,vertical=0.dp)) { Column(horizontalAlignment=Alignment.CenterHorizontally) { Text(label,fontSize=10.sp);Text(moveEvaluations.getOrElse(i+1){"—"},fontSize=8.sp,color=MaterialTheme.colorScheme.primary) } } }
                }
                Row(Modifier.fillMaxWidth(), horizontalArrangement=Arrangement.spacedBy(7.dp), verticalAlignment=Alignment.CenterVertically) {
                    GlenActionButton("FEN", Modifier.weight(1f)) { showFen=true }
                    GlenActionButton("Импорт", Modifier.weight(1f)) { pgnPicker.launch("*/*") }
                    GlenActionButton("Экспорт", Modifier.weight(1f), enabled=pgnMoves.isNotEmpty()) { pgnSaver.launch("GlenMate-game.pgn") }
                    GlenActionButton("Сброс", Modifier.weight(1f)) { fen=ChessPosition.START_FEN; initialFen=ChessPosition.START_FEN; status="Начальная позиция"; selected=null; lastMove=null; moveHistory.clear(); pgnMoves.clear(); movePositions.clear();movePositions.add(ChessPosition.START_FEN);moveEvaluations.clear();moveEvaluations.add("—");currentHistoryIndex=0; best="—" }
                }
                Row(Modifier.fillMaxWidth(), verticalAlignment=Alignment.CenterVertically) {
                    Switch(checked=editMode,onCheckedChange={editMode=it;selected=null})
                    Text("Расстановка", fontSize=12.sp)
                    Spacer(Modifier.weight(1f))
                    Text("Ход: ${if(fen.split(" ").getOrNull(1)=="b") "чёрных" else "белых"}", fontSize=12.sp, fontWeight=FontWeight.SemiBold)
                }
                if(editMode) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement=Arrangement.SpaceBetween) {
                        listOf('K','Q','R','B','N','P','k','q','r','b','n','p','.').forEach { piece ->
                            TextButton(onClick={chosenPiece=piece}, contentPadding=PaddingValues(horizontal=2.dp, vertical=0.dp)) { Text(if(piece=='.')"⌫" else ChessPosition.glyph(piece), color=if(chosenPiece==piece) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface, fontSize=17.sp) }
                        }
                    }
                }
                Spacer(Modifier.height(3.dp))
                Row(Modifier.fillMaxWidth(), verticalAlignment=Alignment.CenterVertically) {
                    Text("Глубина", fontSize=12.sp, fontWeight=FontWeight.SemiBold)
                    Spacer(Modifier.width(8.dp))
                    Slider(value=depth.toFloat(), onValueChange={depth=it.toInt()}, valueRange=10f..30f, steps=19, modifier=Modifier.weight(1f))
                    Text("$depth", fontSize=12.sp, color=MaterialTheme.colorScheme.primary, fontWeight=FontWeight.Bold)
                }
                GlenActionButton(if(busy) "Анализ…" else "Лучший ход", Modifier.fillMaxWidth(), enabled=!busy&&ChessPosition.isPlausibleFen(fen)) {
                    busy=true; status="Анализ выполняется…"
                    scope.launch {
                        val result=withContext(Dispatchers.IO){StockfishEngine(context).analyze(fen,depth)}
                        best=result.bestMove; evaluation=result.evaluation; if(currentHistoryIndex in moveEvaluations.indices) moveEvaluations[currentHistoryIndex]=result.evaluation; status=result.message; busy=false
                    }
                }
                Spacer(Modifier.height(7.dp))
                Card(Modifier.fillMaxWidth(), shape=RoundedCornerShape(8.dp), colors=CardDefaults.cardColors(containerColor=MaterialTheme.colorScheme.surface)) {
                    Column(Modifier.padding(horizontal=14.dp, vertical=9.dp)) {
                        Text("ЛУЧШИЙ ХОД", fontSize=10.sp, letterSpacing=1.5.sp, color=MaterialTheme.colorScheme.primary, fontWeight=FontWeight.Bold)
                        Text(best, fontSize=21.sp, fontWeight=FontWeight.Bold, color=LocalGlenText.current)
                        Text("Оценка позиции: $evaluation", fontSize=13.sp, color=LocalGlenText.current.copy(alpha=.78f))
                    }
                }
                val cp=Regex("([+-]?\\d+\\.\\d+)").find(evaluation)?.groupValues?.get(1)?.toFloatOrNull() ?: 0f
                val whiteShare=((cp/8f)+.5f).coerceIn(0f,1f)
                Row(Modifier.fillMaxWidth().padding(top=4.dp),verticalAlignment=Alignment.CenterVertically) {
                    Text("Ч",fontSize=10.sp,color=MaterialTheme.colorScheme.onSurface.copy(alpha=.65f))
                    LinearProgressIndicator(progress=whiteShare,modifier=Modifier.weight(1f).padding(horizontal=6.dp).height(6.dp),color=MaterialTheme.colorScheme.primary,trackColor=MaterialTheme.colorScheme.onSurface.copy(alpha=.16f))
                    Text("Б",fontSize=10.sp,color=MaterialTheme.colorScheme.onSurface.copy(alpha=.65f))
                }
                Text(status, Modifier.fillMaxWidth().padding(top=3.dp), fontSize=10.sp, color=MaterialTheme.colorScheme.onSurface.copy(alpha=.55f), maxLines=1)
            }
        }
    }
    if(showFen) AlertDialog(onDismissRequest={showFen=false}, title={Text("FEN позиции")}, text={OutlinedTextField(value=fen,onValueChange={fen=it},modifier=Modifier.fillMaxWidth(),minLines=2)}, confirmButton={TextButton(onClick={initialFen=fen;pgnMoves.clear();moveHistory.clear();movePositions.clear();movePositions.add(fen);moveEvaluations.clear();moveEvaluations.add("—");currentHistoryIndex=0;lastMove=null;best="—";showFen=false}){Text("Готово")}}, dismissButton={TextButton(onClick={fen=ChessPosition.START_FEN;showFen=false}){Text("Начальная позиция")}}, shape=RoundedCornerShape(10.dp))
}

@Composable
private fun GlenActionButton(label:String, modifier:Modifier=Modifier, enabled:Boolean=true, onClick:()->Unit) {
    Button(onClick=onClick, modifier=modifier.heightIn(min=38.dp), enabled=enabled, shape=RoundedCornerShape(7.dp), contentPadding=PaddingValues(horizontal=8.dp, vertical=5.dp), colors=ButtonDefaults.buttonColors(containerColor=LocalGlenButton.current, contentColor=Color(0xFF142019))) {
        Text(label, fontSize=12.sp, maxLines=1)
    }
}

@Composable
fun ChessBoard(
    fen:String,
    selected:Int?,
    legalTargets:Set<Int> = emptySet(),
    lastMove:String? = null,
    checkSquare:Int? = null,
    bestMove:String = "—",
    onSquare:(Int)->Unit
) {
    val cells=remember(fen){ChessPosition.boardChars(fen)}
    Box(Modifier.fillMaxSize().aspectRatio(1f)) {
        Column(Modifier.fillMaxSize()) {
            for(r in 0..7) Row(Modifier.weight(1f)) {
                for(c in 0..7) {
                    val i=r*8+c; val light=LocalBoardLight.current; val dark=LocalBoardDark.current
                    val isLast=lastMove?.let { ChessPosition.squareIndex(it.substring(0,2))==i || ChessPosition.squareIndex(it.substring(2,4))==i }==true
                    val color=when { selected==i -> Color(0xFFE7C66A); checkSquare==i -> Color(0xFFE36B65); isLast -> Color(0xFFB7C978); else -> if((r+c)%2==0)light else dark }
                    Box(Modifier.weight(1f).fillMaxHeight().background(color).clickable{onSquare(i)},contentAlignment=Alignment.Center) {
                        val piece=cells.getOrElse(i){'.'}
                        Text(if(piece=='.')"" else ChessPosition.glyph(piece),fontSize=29.sp,color=if(piece.isUpperCase())Color(0xFFFAF8F1)else Color(0xFF172019))
                        if(c==0) Text("${8-r}",Modifier.align(Alignment.TopStart).padding(start=2.dp,top=1.dp),fontSize=8.sp,fontWeight=FontWeight.Bold,color=if((r+c)%2==0)Color(0xFF53645D)else Color(0xFFECE8DD))
                        if(r==7) Text("${'a'+c}",Modifier.align(Alignment.BottomEnd).padding(end=2.dp,bottom=0.dp),fontSize=8.sp,fontWeight=FontWeight.Bold,color=if((r+c)%2==0)Color(0xFF53645D)else Color(0xFFECE8DD))
                        if(i in legalTargets && piece=='.') Box(Modifier.size(10.dp).background(Color(0x990E2920),RoundedCornerShape(50)))
                        if(i in legalTargets && piece!='.') Box(Modifier.fillMaxSize().padding(3.dp).background(Color.Transparent, RoundedCornerShape(2.dp)))
                    }
                }
            }
        }
        Canvas(Modifier.fillMaxSize()) {
            val cell=size.width/8f
            fun center(index:Int)=Offset((index%8+.5f)*cell,(index/8+.5f)*cell)
            if(selected!=null) {
                val origin=center(selected!!)
                legalTargets.forEach { target ->
                    val destination=center(target)
                    drawLine(Color(0xAA2F83D5),origin,destination,strokeWidth=cell*.035f,cap=StrokeCap.Round)
                }
            }
            if(bestMove.length>=4 && bestMove!="—") {
                val from=ChessPosition.squareIndex(bestMove.substring(0,2)); val to=ChessPosition.squareIndex(bestMove.substring(2,4))
                if(from>=0&&to>=0) {
                    val a=center(from);val b=center(to)
                    drawLine(Color(0xDD16A36A),a,b,strokeWidth=cell*.09f,cap=StrokeCap.Round)
                    val angle=kotlin.math.atan2((b.y-a.y).toDouble(),(b.x-a.x).toDouble()).toFloat(); val len=cell*.25f
                    val left=Offset(b.x-len*kotlin.math.cos(angle-.55f),b.y-len*kotlin.math.sin(angle-.55f)); val right=Offset(b.x-len*kotlin.math.cos(angle+.55f),b.y-len*kotlin.math.sin(angle+.55f))
                    drawLine(Color(0xDD16A36A),b,left,strokeWidth=cell*.09f,cap=StrokeCap.Round);drawLine(Color(0xDD16A36A),b,right,strokeWidth=cell*.09f,cap=StrokeCap.Round)
                }
            }
        }
    }
}

data class EngineResult(val bestMove: String, val evaluation: String, val pv: String, val message: String)

class StockfishEngine(private val context: android.content.Context) {
    fun analyze(fen: String, depth: Int): EngineResult = try {
        val abi = android.os.Build.SUPPORTED_ABIS.firstOrNull() ?: "unknown"
        val target = java.io.File(context.filesDir, "stockfish")
        context.assets.open("stockfish/$abi/stockfish").use { input -> target.outputStream().use { input.copyTo(it) } }
        target.setExecutable(true)
        val process = ProcessBuilder(target.absolutePath).redirectErrorStream(true).start()
        val writer = process.outputStream.bufferedWriter()
        val reader = process.inputStream.bufferedReader()
        fun send(s: String) { writer.write(s); writer.newLine(); writer.flush() }
        send("uci")
        var line: String?
        var ready = false
        while (true) { line = reader.readLine() ?: break; if (line == "uciok") { ready = true; break } }
        if (!ready) error("Stockfish не ответил на UCI")
        send("isready")
        while (reader.readLine()?.trim() != "readyok") { }
        send("position fen $fen"); send("go depth $depth")
        var best = "—"; var score = "—"; var variation = ""
        while (true) {
            line = reader.readLine() ?: break
            if (line!!.startsWith("info ") && line!!.contains(" score ")) {
                val t = line!!.split(" "); val si = t.indexOf("score")
                if (si >= 0 && si+2 < t.size) score = when(t[si+1]) {
                    "cp" -> "%+.2f пешки".format(java.util.Locale.US, (t[si+2].toInt()/100.0) * if (fen.trim().split(Regex("\\s+" )).getOrNull(1)=="b") -1 else 1)
                    "mate" -> "мат в ${t[si+2]}"
                    else -> score
                }
                val pi = t.indexOf("pv"); if (pi >= 0) variation = t.drop(pi+1).take(12).joinToString(" ")
            }
            if (line!!.startsWith("bestmove ")) { best = line!!.split(" ").getOrNull(1) ?: "—"; break }
        }
        send("quit"); process.waitFor()
        EngineResult(best, score, variation, "Анализ завершён на глубине $depth.")
    } catch (e: Exception) {
        EngineResult("—", "—", "", "Stockfish не найден или не запустился: ${e.message}. Добавьте бинарник для ABI устройства.")
    }
}

object ChessPosition {
    const val START_FEN = "rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1"
    fun boardChars(fen: String): List<Char> {
        val placement = fen.trim().split(Regex("\\s+")).firstOrNull() ?: return List(64) { '.' }
        val ranks = placement.split('/')
        if (ranks.size != 8) return List(64) { '.' }
        val out = mutableListOf<Char>()
        for (rank in ranks) {
            var count = 0
            for (ch in rank) {
                if (ch in '1'..'8') { count += ch.digitToInt(); repeat(ch.digitToInt()) { out.add('.') } }
                else if (ch in "KQRBNPkqrbnp") { count++; out.add(ch) }
                else return List(64) { '.' }
            }
            if (count != 8) return List(64) { '.' }
        }
        return if (out.size == 64) out else List(64) { '.' }
    }
    fun squareName(i: Int) = "${'a' + i % 8}${8 - i / 8}"
    fun squareIndex(s: String): Int {
        if (s.length != 2 || s[0] !in 'a'..'h' || s[1] !in '1'..'8') return -1
        return (8 - (s[1] - '0')) * 8 + (s[0] - 'a')
    }
    fun glyph(p: Char) = when (p) {
        'K'->"♔"; 'Q'->"♕"; 'R'->"♖"; 'B'->"♗"; 'N'->"♘"; 'P'->"♙"
        'k'->"♚"; 'q'->"♛"; 'r'->"♜"; 'b'->"♝"; 'n'->"♞"; 'p'->"♟"; else->""
    }
    private fun fields(fen: String) = fen.trim().split(Regex("\\s+")).let { if (it.size >= 6) it else listOf(it.getOrElse(0){""}, "w", "-", "-", "0", "1") }
    fun isPlausibleFen(fen: String): Boolean {
        val p = fen.trim().split(Regex("\\s+"))
        if (p.size != 6 || p[1] !in listOf("w", "b")) return false
        if (p[2].any { it !in "KQkq-" } || (p[3] != "-" && squareIndex(p[3]) < 0)) return false
        val b = boardChars(fen)
        if(b.count { it == 'K' } != 1 || b.count { it == 'k' } != 1) return false
        if((0..7).any { b[it]=='P' || b[it]=='p' } || (56..63).any { b[it]=='P' || b[it]=='p' }) return false
        val whiteKing=b.indexOf('K'); val blackKing=b.indexOf('k')
        val whiteChecked=attacked(b,whiteKing,false); val blackChecked=attacked(b,blackKing,true)
        if(whiteChecked && blackChecked) return false
        if(p[1]=="w" && blackChecked) return false
        if(p[1]=="b" && whiteChecked) return false
        return true
    }
    fun withBoard(fen: String, cells: List<Char>): String {
        val board = (0..7).joinToString("/") { r ->
            val s = StringBuilder(); var empty = 0
            cells.subList(r*8, r*8+8).forEach { if (it == '.') empty++ else { if (empty > 0) s.append(empty); empty = 0; s.append(it) } }
            if (empty > 0) s.append(empty); s.toString()
        }
        val p = fields(fen)
        return "$board ${p[1]} ${p[2]} ${p[3]} ${p[4]} ${p[5]}"
    }
    private fun white(piece: Char) = piece.isUpperCase()
    private fun inside(r: Int, c: Int) = r in 0..7 && c in 0..7
    private fun attacked(board: List<Char>, target: Int, byWhite: Boolean): Boolean {
        val tr = target / 8; val tc = target % 8
        for (i in 0..63) {
            val p = board[i]; if (p == '.' || white(p) != byWhite) continue
            val r = i / 8; val c = i % 8; val dr = tr-r; val dc = tc-c
            when (p.lowercaseChar()) {
                'p' -> if (dr == (if (byWhite) -1 else 1) && kotlin.math.abs(dc) == 1) return true
                'n' -> if ((kotlin.math.abs(dr)==2 && kotlin.math.abs(dc)==1)||(kotlin.math.abs(dr)==1 && kotlin.math.abs(dc)==2)) return true
                'k' -> if (kotlin.math.max(kotlin.math.abs(dr), kotlin.math.abs(dc)) == 1) return true
                'b','r','q' -> {
                    val diagonal = kotlin.math.abs(dr)==kotlin.math.abs(dc) && dr!=0
                    val straight = (dr==0) xor (dc==0)
                    val allowed = (p.lowercaseChar()=='q' && (diagonal || straight)) || (p.lowercaseChar()=='b' && diagonal) || (p.lowercaseChar()=='r' && straight)
                    if (allowed) {
                        val sr = dr.compareTo(0); val sc = dc.compareTo(0); var rr=r+sr; var cc=c+sc; var clear=true
                        while (rr!=tr || cc!=tc) { if (board[rr*8+cc] != '.') { clear=false; break }; rr+=sr; cc+=sc }
                        if (clear) return true
                    }
                }
            }
        }
        return false
    }
    fun isInCheck(fen: String, whiteKing: Boolean = fields(fen)[1] == "w"): Boolean {
        val b = boardChars(fen); val king = if (whiteKing) 'K' else 'k'; val at = b.indexOf(king)
        return at >= 0 && attacked(b, at, !whiteKing)
    }
    private fun pseudoMoves(fen: String, from: Int): List<String> {
        val p = fields(fen); val b = boardChars(fen); val piece = b.getOrElse(from){'.'}
        if (piece == '.' || white(piece) != (p[1] == "w")) return emptyList()
        val r=from/8; val c=from%8; val result=mutableListOf<String>()
        fun add(rr:Int, cc:Int) { if (!inside(rr,cc)) return; val to=rr*8+cc; val dest=b[to]; if (dest=='.' || (white(dest)!=white(piece) && dest.lowercaseChar()!='k')) result.add(squareName(from)+squareName(to)) }
        when(piece.lowercaseChar()) {
            'p' -> {
                val dir=if(white(piece)) -1 else 1; val start=if(white(piece)) 6 else 1
                if(inside(r+dir,c) && b[(r+dir)*8+c]=='.') { add(r+dir,c); if(r==start && b[(r+2*dir)*8+c]=='.') add(r+2*dir,c) }
                for(dc in listOf(-1,1)) if(inside(r+dir,c+dc)) { val to=(r+dir)*8+c+dc; if(b[to]!='.' && white(b[to])!=white(piece) && b[to].lowercaseChar()!='k') result.add(squareName(from)+squareName(to)); if(p[3]==squareName(to)) result.add(squareName(from)+squareName(to)) }
            }
            'n' -> listOf(-2 to -1,-2 to 1,-1 to -2,-1 to 2,1 to -2,1 to 2,2 to -1,2 to 1).forEach{add(r+it.first,c+it.second)}
            'k' -> { for(dr in -1..1) for(dc in -1..1) if(dr!=0||dc!=0)add(r+dr,c+dc)
                val rights=p[2]; if(white(piece)&&from==60&&!attacked(b,60,false)) {
                    if('K' in rights && b[61]=='.'&&b[62]=='.'&&b[63]=='R'&&!attacked(b,61,false)&&!attacked(b,62,false)) result.add("e1g1")
                    if('Q' in rights && b[59]=='.'&&b[58]=='.'&&b[57]=='.'&&b[56]=='R'&&!attacked(b,59,false)&&!attacked(b,58,false)) result.add("e1c1")
                }
                if(!white(piece)&&from==4&&!attacked(b,4,true)) {
                    if('k' in rights&&b[5]=='.'&&b[6]=='.'&&b[7]=='r'&&!attacked(b,5,true)&&!attacked(b,6,true)) result.add("e8g8")
                    if('q' in rights&&b[3]=='.'&&b[2]=='.'&&b[1]=='.'&&b[0]=='r'&&!attacked(b,3,true)&&!attacked(b,2,true)) result.add("e8c8")
                }
            }
            'b','r','q' -> {
                val dirs=mutableListOf<Pair<Int,Int>>(); if(piece.lowercaseChar()!='r') dirs.addAll(listOf(-1 to -1,-1 to 1,1 to -1,1 to 1)); if(piece.lowercaseChar()!='b') dirs.addAll(listOf(-1 to 0,1 to 0,0 to -1,0 to 1))
                for((dr,dc) in dirs){var rr=r+dr;var cc=c+dc;while(inside(rr,cc)){val to=rr*8+cc; if(b[to]=='.')result.add(squareName(from)+squareName(to)) else {if(white(b[to])!=white(piece) && b[to].lowercaseChar()!='k')result.add(squareName(from)+squareName(to));break};rr+=dr;cc+=dc}}
            }
        }
        return result
    }
    private fun rawApply(fen: String, uci: String): String? {
        if(uci.length !in 4..5) return null
        val p=fields(fen); val b=boardChars(fen).toMutableList(); val a=squareIndex(uci.substring(0,2)); val z=squareIndex(uci.substring(2,4))
        if(a !in 0..63 || z !in 0..63 || b[a]=='.') return null
        val piece=b[a]; val target=b[z]; var rights=p[2]; var ep="-"
        if(piece=='K') rights=rights.replace("K","").replace("Q","")
        if(piece=='k') rights=rights.replace("k","").replace("q","")
        if(a==63||z==63)rights=rights.replace("K",""); if(a==56||z==56)rights=rights.replace("Q","")
        if(a==7||z==7)rights=rights.replace("k",""); if(a==0||z==0)rights=rights.replace("q","")
        if(piece.lowercaseChar()=='p' && p[3]!="-" && z==squareIndex(p[3]) && a%8!=z%8 && target=='.') b[if(piece.isUpperCase())z+8 else z-8]='.'
        b[a]='.'; b[z]=if(uci.length==5) if(piece.isUpperCase())uci[4].uppercaseChar() else uci[4].lowercaseChar() else piece
        if(piece=='K'&&a==60&&z==62){b[63]='.';b[61]='R'}; if(piece=='K'&&a==60&&z==58){b[56]='.';b[59]='R'}
        if(piece=='k'&&a==4&&z==6){b[7]='.';b[5]='r'}; if(piece=='k'&&a==4&&z==2){b[0]='.';b[3]='r'}
        if(piece.lowercaseChar()=='p'&&kotlin.math.abs(z-a)==16)ep=squareName((z+a)/2)
        val half=if(piece.lowercaseChar()=='p'||target!='.')0 else (p[4].toIntOrNull()?:0)+1
        val full=(p[5].toIntOrNull()?:1)+(if(p[1]=="b")1 else 0)
        return "${encodeBoard(b)} ${if(p[1]=="w")"b" else "w"} ${rights.ifEmpty{"-"}} $ep $half $full"
    }
    private fun encodeBoard(b:List<Char>)=(0..7).joinToString("/"){r->val s=StringBuilder();var e=0;for(c in 0..7){val x=b[r*8+c];if(x=='.')e++ else {if(e>0)s.append(e);e=0;s.append(x)}};if(e>0)s.append(e);s.toString()}
    fun legalMoves(fen: String, from: Int? = null): List<String> {
        val b=boardChars(fen); val side=fields(fen)[1]=="w"
        val starts=if(from!=null) listOf(from) else (0..63).filter{b[it]!='.'&&white(b[it])==side}
        return starts.flatMap{pseudoMoves(fen,it)}.flatMap { move ->
            val piece=b[squareIndex(move.substring(0,2))]; val promotes=piece.lowercaseChar()=='p' && (move[3]=='8'||move[3]=='1')
            if(promotes) listOf("q","r","b","n").map{move+it} else listOf(move)
        }.filter { move -> val next=rawApply(fen,move)?:return@filter false; !isInCheck(next,side) }
    }
    fun applyUci(fen: String, uci: String): String? = if(uci in legalMoves(fen)) rawApply(fen,uci) else null
    fun legalTargets(fen:String, from:Int):Set<Int> = legalMoves(fen,from).mapNotNull{squareIndex(it.substring(2,4)).takeIf{x->x>=0}}.toSet()
    fun checkKingSquare(fen:String):Int? { val side=fields(fen)[1]=="w"; if(!isInCheck(fen,side))return null; return boardChars(fen).indexOf(if(side)'K' else 'k').takeIf{it>=0} }
    fun isCheckmate(fen:String)=isInCheck(fen,fields(fen)[1]=="w")&&legalMoves(fen).isEmpty()
    fun isStalemate(fen:String)=!isInCheck(fen,fields(fen)[1]=="w")&&legalMoves(fen).isEmpty()
}
data class ParsedPgn(val initialFen:String,val finalFen:String,val moves:List<String>)

object PgnImporter {
    fun parseGame(pgn:String):ParsedPgn? {
        val initial=Regex("""(?m)^\[FEN\s+"([^"]+)"\]""").find(pgn)?.groupValues?.get(1) ?: ChessPosition.START_FEN
        if(!ChessPosition.isPlausibleFen(initial)) return null
        var fen=initial; val uciMoves=mutableListOf<String>()
        val body=pgn.lines().filterNot{it.trim().startsWith("[")}.joinToString(" ")
            .replace(Regex("\\{[^}]*}\\s*")," ").replace(Regex("\\([^)]*\\)")," ").replace(Regex("\\$[0-9]+")," ")
        val tokens=body.split(Regex("\\s+")).map{it.trim()}.filter{it.isNotEmpty()}
            .map{it.replace(Regex("^[0-9]+\\.{1,3}"),"")}.filter{it.isNotEmpty() && it !in listOf("1-0","0-1","1/2-1/2","*")}
        for(raw in tokens) {
            val san=raw.trim().replace(Regex("[!?+#]+$"),"")
            val move=resolveSan(fen,san) ?: return null
            fen=ChessPosition.applyUci(fen,move) ?: return null
            uciMoves.add(move)
        }
        return ParsedPgn(initial,fen,uciMoves)
    }
    private fun resolveSan(fen:String,san:String):String? {
        val normalized=san.replace('0','O')
        if(normalized=="O-O" || normalized=="O-O-O") {
            val from=if(fen.split(" ").getOrNull(1)=="w") "e1" else "e8"
            val to=if(normalized=="O-O") if(from=="e1")"g1" else "g8" else if(from=="e1")"c1" else "c8"
            return (from+to).takeIf{it in ChessPosition.legalMoves(fen)}
        }
        val match=Regex("^([KQRBN]?)([a-h]?[1-8]?)(x?)([a-h][1-8])(?:=?([QRBN]))?$").matchEntire(san) ?: return null
        val kind=match.groupValues[1].ifEmpty{"P"}[0]
        val disambiguation=match.groupValues[2]; val capture=match.groupValues[3].isNotEmpty(); val target=ChessPosition.squareIndex(match.groupValues[4]); val promotion=match.groupValues[5].lowercase()
        val board=ChessPosition.boardChars(fen)
        val candidates=ChessPosition.legalMoves(fen).filter { uci ->
            val from=ChessPosition.squareIndex(uci.substring(0,2)); val to=ChessPosition.squareIndex(uci.substring(2,4)); val piece=board[from]
            if(piece.uppercaseChar()!=kind || to!=target) return@filter false
            if(disambiguation.any{it in 'a'..'h'} && uci[0]!=disambiguation.first{it in 'a'..'h'}) return@filter false
            if(disambiguation.any{it in '1'..'8'} && uci[1]!=disambiguation.first{it in '1'..'8'}) return@filter false
            val isCapture=board[to]!='.' || (piece.lowercaseChar()=='p' && uci[0]!=uci[2] && fen.split(" ").getOrNull(3)==match.groupValues[4])
            if(capture!=isCapture) return@filter false
            if(promotion.isNotEmpty() && uci.getOrNull(4)?.toString()!=promotion) return@filter false
            if(promotion.isEmpty() && uci.length==5) return@filter false
            true
        }
        return candidates.singleOrNull()
    }
    fun tryReadFenOrUci(pgn:String):String? = parseGame(pgn)?.finalFen
}

object PgnExporter {
    fun export(initialFen:String,moves:List<String>):String {
        var fen=initialFen; val san=mutableListOf<String>()
        for(move in moves) { val notation=toSan(fen,move) ?: return ""; san.add(notation); fen=ChessPosition.applyUci(fen,move) ?: return "" }
        val headers=buildString { appendLine("[Event \"GlenMate Game\"]"); appendLine("[Site \"GlenMate\"]"); appendLine("[Date \"????.??.??\"]"); appendLine("[Result \"*\"]"); if(initialFen!=ChessPosition.START_FEN){appendLine("[SetUp \"1\"]");appendLine("[FEN \"$initialFen\"]")} }
        val blackStarts=initialFen.split(" ").getOrNull(1)=="b"
        val body=if(blackStarts) {
            buildString { san.forEachIndexed { i,move -> if(i==0) append("${initialFen.split(" ").getOrNull(5)?.toIntOrNull()?:1}... ") else if(i%2==1) append("${(initialFen.split(" ").getOrNull(5)?.toIntOrNull()?:1)+i/2}. "); append(move); append(' ') } }.trim()
        } else san.chunked(2).mapIndexed{index,pair->"${(initialFen.split(" ").getOrNull(5)?.toIntOrNull()?:1)+index}. "+pair.joinToString(" ")}.joinToString(" ")
        return headers+"\n"+body+if(body.isNotEmpty())" *\n" else "*\n"
    }
    private fun toSan(fen:String,uci:String):String? {
        if(uci !in ChessPosition.legalMoves(fen)) return null
        val board=ChessPosition.boardChars(fen); val from=ChessPosition.squareIndex(uci.substring(0,2)); val to=ChessPosition.squareIndex(uci.substring(2,4)); val piece=board[from]; val target=board[to]
        if(piece.lowercaseChar()=='k' && kotlin.math.abs(to-from)==2) return if(to>from)"O-O" else "O-O-O"
        val capture=target!='.' || (piece.lowercaseChar()=='p' && from%8!=to%8)
        val kind=if(piece.lowercaseChar()=='p')"" else piece.uppercaseChar().toString()
        var dis=""
        if(kind.isNotEmpty()) {
            val alternatives=ChessPosition.legalMoves(fen).filter{it!=uci && it.substring(2,4)==uci.substring(2,4) && board[ChessPosition.squareIndex(it.substring(0,2))].uppercaseChar()==piece.uppercaseChar()}
            if(alternatives.isNotEmpty()) {
                val sameFile=alternatives.any{it[0]==uci[0]}; val sameRank=alternatives.any{it[1]==uci[1]}
                dis=when { !sameFile->uci[0].toString(); !sameRank->uci[1].toString(); else->uci.substring(0,2) }
            }
        } else if(capture) dis=uci[0].toString()
        val promotion=if(uci.length==5)"="+uci[4].uppercaseChar() else ""
        val base=kind+dis+(if(capture)"x" else "")+uci.substring(2,4)+promotion
        val next=ChessPosition.applyUci(fen,uci) ?: return null
        return base+if(ChessPosition.isCheckmate(next))"#" else if(ChessPosition.isInCheck(next))"+" else ""
    }
}
