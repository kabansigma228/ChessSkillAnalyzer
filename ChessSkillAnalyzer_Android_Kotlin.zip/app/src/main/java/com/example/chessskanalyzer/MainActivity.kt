package com.example.chessskanalyzer

import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState); setContent { ChessAnalyzerApp() } }
}

@Composable
fun ChessAnalyzerApp() {
    val context = androidx.compose.ui.platform.LocalContext.current
    val scope = rememberCoroutineScope()
    var fen by remember { mutableStateOf(ChessPosition.START_FEN) }
    var status by remember { mutableStateOf("Загрузите позицию или расставьте фигуры.") }
    var best by remember { mutableStateOf("—") }
    var evaluation by remember { mutableStateOf("—") }
    var pv by remember { mutableStateOf("") }
    var depth by remember { mutableIntStateOf(18) }
    var busy by remember { mutableStateOf(false) }
    var selected by remember { mutableStateOf<Int?>(null) }
    var editMode by remember { mutableStateOf(false) }
    var chosenPiece by remember { mutableStateOf('Q') }
    var photoUri by remember { mutableStateOf<Uri?>(null) }
    var darkTheme by remember { mutableStateOf(true) }
    var accentIndex by remember { mutableIntStateOf(0) }
    var language by remember { mutableStateOf("Русский") }
    var showSettings by remember { mutableStateOf(false) }
    val accents = listOf(Color(0xFF3D8B68), Color(0xFF4776C5), Color(0xFF9A6BC2), Color(0xFFB47A35), Color(0xFFB85C68))
    val accent = accents[accentIndex]

    val photoPicker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) {
            photoUri = uri
            status = "Фото загружено. Распознавание фигур пока не автоматизировано: используйте снимок как образец и расставьте позицию вручную."
        }
    }
    val pgnPicker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) {
            runCatching { context.contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() } ?: error("Файл не открыт") }
                .onSuccess { text ->
                    val parsed = PgnImporter.tryReadFenOrUci(text)
                    if (parsed != null) { fen = parsed; status = "Позиция из PGN загружена." }
                    else status = "Не удалось разобрать PGN. Поддерживается FEN-тег или координатные UCI-ходы; стандартная SAN-нотация пока не поддерживается."
                }.onFailure { status = "Ошибка чтения PGN: ${it.message}" }
        }
    }

    val appColors = if (darkTheme) {
        darkColorScheme(primary = accent, background = Color(0xFF101713), surface = Color(0xFF1B2821))
    } else {
        lightColorScheme(primary = accent, background = Color(0xFFF4F6F3), surface = Color.White)
    }
    MaterialTheme(colorScheme = appColors) {
        Scaffold(containerColor = MaterialTheme.colorScheme.background) { padding ->
            LazyColumn(Modifier.fillMaxSize().padding(padding).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                item {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text("GlenMate", fontSize = 28.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                            Text("Твой шахматный помощник", color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        OutlinedButton(onClick = { showSettings = true }) { Text("⚙") }
                    }
                }
                item {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(onClick = { photoPicker.launch("image/*") }, modifier = Modifier.weight(1f)) { Text("Фото доски") }
                        Button(onClick = { pgnPicker.launch("*/*") }, modifier = Modifier.weight(1f)) { Text("Импорт PGN") }
                    }
                }
                item {
                    Text("Шахматная доска", fontWeight = FontWeight.Bold, fontSize = 18.sp)
                    ChessBoard(fen, selected, onSquare = { index ->
                        if (editMode) {
                            val cells = ChessPosition.boardChars(fen).toMutableList()
                            cells[index] = chosenPiece
                            fen = ChessPosition.withBoard(fen, cells)
                        } else if (selected == null) selected = index else {
                            val from = ChessPosition.squareName(selected!!)
                            val to = ChessPosition.squareName(index)
                            val updated = ChessPosition.applyUci(fen, from + to)
                            if (updated != null) { fen = updated; status = "Ход $from$to внесён. Легальность проверяется движком при анализе." }
                            else status = "Не удалось применить ход."
                            selected = null
                        }
                    })
                }
                item {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Switch(checked = editMode, onCheckedChange = { editMode = it; selected = null })
                        Spacer(Modifier.width(8.dp))
                        Text(if (editMode) "Режим расстановки фигур" else "Режим ввода хода")
                    }
                    if (editMode) {
                        Text("Выберите фигуру, затем клетку. ⌫ очищает клетку.", color = Color.LightGray, fontSize = 12.sp)
                        Row(horizontalArrangement = Arrangement.spacedBy(1.dp)) {
                            listOf('K','Q','R','B','N','P','k','q','r','b','n','p','.').forEach { p ->
                                TextButton(onClick = { chosenPiece = p }) {
                                    Text(if (p == '.') "⌫" else ChessPosition.glyph(p), fontSize = 18.sp,
                                        color = if (chosenPiece == p) Color(0xFF8BC6A2) else Color.White)
                                }
                            }
                        }
                    }
                }
                item {
                    OutlinedTextField(value = fen, onValueChange = { fen = it }, label = { Text("FEN позиции") }, modifier = Modifier.fillMaxWidth(), minLines = 2)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(onClick = { status = if (ChessPosition.isPlausibleFen(fen)) "Формат FEN выглядит корректно." else "Проверьте формат FEN." }, modifier = Modifier.weight(1f)) { Text("Проверить FEN") }
                        OutlinedButton(onClick = { fen = ChessPosition.START_FEN; status = "Начальная позиция." }, modifier = Modifier.weight(1f)) { Text("Сбросить") }
                    }
                }
                item {
                    Text("Глубина анализа: $depth")
                    Slider(value = depth.toFloat(), onValueChange = { depth = it.toInt() }, valueRange = 10f..30f, steps = 19)
                    Button(onClick = {
                        busy = true; status = "Выполняется анализ…"
                        scope.launch {
                            val result = withContext(Dispatchers.IO) { StockfishEngine(context).analyze(fen, depth) }
                            best = result.bestMove; evaluation = result.evaluation; pv = result.pv; status = result.message; busy = false
                        }
                    }, enabled = !busy && ChessPosition.isPlausibleFen(fen), modifier = Modifier.fillMaxWidth()) {
                        Text(if (busy) "Анализ…" else "Найти лучший ход")
                    }
                }
                item {
                    Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF203329))) {
                        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            Text("РЕЗУЛЬТАТ АНАЛИЗА", color = Color(0xFFB7E4C7), fontWeight = FontWeight.Bold)
                            Text("Лучший ход: $best", fontSize = 20.sp, fontWeight = FontWeight.Bold)
                            Text("Оценка: $evaluation")
                            if (pv.isNotBlank()) Text("Вариант: $pv")
                            Text(status, color = Color.LightGray, fontSize = 12.sp)
                        }
                    }
                }
            }
        }
        if (showSettings) {
            AlertDialog(
                onDismissRequest = { showSettings = false },
                title = { Text("Настройки GlenMate") },
                text = {
                    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        Text("Оформление", fontWeight = FontWeight.SemiBold)
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text("Тёмная тема", modifier = Modifier.weight(1f))
                            Switch(checked = darkTheme, onCheckedChange = { darkTheme = it })
                        }
                        Text("Акцентный цвет", fontWeight = FontWeight.SemiBold)
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            accents.forEachIndexed { index, color ->
                                Box(
                                    Modifier.size(34.dp).background(color, androidx.compose.foundation.shape.CircleShape)
                                        .clickable { accentIndex = index },
                                    contentAlignment = Alignment.Center
                                ) {
                                    if (accentIndex == index) Text("✓", color = Color.White, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                        Text("Язык интерфейса", fontWeight = FontWeight.SemiBold)
                        var languageMenu by remember { mutableStateOf(false) }
                        Box {
                            OutlinedButton(onClick = { languageMenu = true }) { Text(language) }
                            DropdownMenu(expanded = languageMenu, onDismissRequest = { languageMenu = false }) {
                                listOf("Русский", "English", "Deutsch", "Español", "Français", "Polski").forEach { item ->
                                    DropdownMenuItem(text = { Text(item) }, onClick = {
                                        language = item
                                        languageMenu = false
                                    })
                                }
                            }
                        }
                        Text("Выбор языка сохранён в настройках текущего сеанса. Полная локализация появится в следующем обновлении.",
                            style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                },
                confirmButton = { TextButton(onClick = { showSettings = false }) { Text("Готово") } }
            )
        }
    }
}

@Composable
fun ChessBoard(fen: String, selected: Int?, onSquare: (Int) -> Unit) {
    val cells = remember(fen) { ChessPosition.boardChars(fen) }
    Column(Modifier.fillMaxWidth().aspectRatio(1f)) {
        for (r in 0..7) Row(Modifier.weight(1f)) {
            for (c in 0..7) {
                val i = r * 8 + c
                val color = if (selected == i) Color(0xFFE8D36A) else if ((r+c)%2==0) Color(0xFFE8DCC4) else Color(0xFF77966D)
                Box(Modifier.weight(1f).fillMaxHeight().background(color).clickable { onSquare(i) }, contentAlignment = Alignment.Center) {
                    val piece = cells.getOrElse(i) { '.' }
                    Text(if (piece == '.') "" else ChessPosition.glyph(piece), fontSize = 30.sp,
                        color = if (piece.isUpperCase()) Color(0xFFF8F5EA) else Color(0xFF172019))
                }
            }
        }
    }
}

data class EngineResult(val bestMove: String, val evaluation: String, val pv: String, val message: String)

class StockfishEngine(private val context: android.content.Context) {
    fun analyze(fen: String, depth: Int): EngineResult = try {
        val abi = android.os.Build.SUPPORTED_ABIS.firstOrNull() ?: "unknown"
        val target = java.io.File(context.filesDir, "stockfish")
        context.assets.open("stockfish/$abi/stockfish").use { input -> target.outputStream().use { input.copyTo(it) } }
        target.setExecutable(true)
        val process = ProcessBuilder(target.absolutePath).redirectErrorStream(true).start()
        val writer = process.outputStream.bufferedWriter()
        val reader = process.inputStream.bufferedReader()
        fun send(s: String) { writer.write(s); writer.newLine(); writer.flush() }
        send("uci")
        var line: String?
        var ready = false
        while (true) { line = reader.readLine() ?: break; if (line == "uciok") { ready = true; break } }
        if (!ready) error("Stockfish не ответил на UCI")
        send("isready")
        while (reader.readLine()?.trim() != "readyok") { }
        send("position fen $fen"); send("go depth $depth")
        var best = "—"; var score = "—"; var variation = ""
        while (true) {
            line = reader.readLine() ?: break
            if (line!!.startsWith("info ") && line!!.contains(" score ")) {
                val t = line!!.split(" "); val si = t.indexOf("score")
                if (si >= 0 && si+2 < t.size) score = when(t[si+1]) {
                    "cp" -> "%+.2f пешки".format(java.util.Locale.US, t[si+2].toInt()/100.0)
                    "mate" -> "мат в ${t[si+2]}"
                    else -> score
                }
                val pi = t.indexOf("pv"); if (pi >= 0) variation = t.drop(pi+1).take(12).joinToString(" ")
            }
            if (line!!.startsWith("bestmove ")) { best = line!!.split(" ").getOrNull(1) ?: "—"; break }
        }
        send("quit"); process.waitFor()
        EngineResult(best, score, variation, "Анализ завершён на глубине $depth.")
    } catch (e: Exception) {
        EngineResult("—", "—", "", "Stockfish не найден или не запустился: ${e.message}. Добавьте бинарник для ABI устройства.")
    }
}

object ChessPosition {
    const val START_FEN = "rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1"
    fun boardChars(fen: String): List<Char> {
        val ranks = fen.trim().substringBefore(' ').split('/')
        if (ranks.size != 8) return List(64) { '.' }
        val out = mutableListOf<Char>()
        ranks.forEach { rank -> rank.forEach { ch -> if (ch.isDigit()) repeat(ch.digitToInt()) { out.add('.') } else out.add(ch) } }
        return if (out.size == 64) out else List(64) { '.' }
    }
    fun squareName(i: Int) = "${'a' + i%8}${8-i/8}"
    fun glyph(p: Char) = when(p) {
        'K'->"♔"; 'Q'->"♕"; 'R'->"♖"; 'B'->"♗"; 'N'->"♘"; 'P'->"♙"
        'k'->"♚"; 'q'->"♛"; 'r'->"♜"; 'b'->"♝"; 'n'->"♞"; 'p'->"♟"; else->""
    }
    fun isPlausibleFen(fen: String): Boolean {
        val p = fen.trim().split(Regex("\\s+")); if (p.size != 6 || p[1] !in listOf("w","b")) return false
        val ranks = p[0].split('/'); if (ranks.size != 8) return false
        return ranks.all { rank -> var n=0; for(ch in rank) { if(ch.isDigit()) n+=ch.digitToInt() else if(ch in "KQRBNPkqrbnp") n++ else return@all false }; n==8 }
    }
    fun withBoard(fen: String, cells: List<Char>): String {
        val board = (0..7).joinToString("/") { r ->
            val s=StringBuilder(); var empty=0
            cells.subList(r*8,r*8+8).forEach { if(it=='.') empty++ else { if(empty>0)s.append(empty); empty=0; s.append(it) } }
            if(empty>0)s.append(empty); s.toString()
        }
        val p=fen.trim().split(Regex("\\s+")); val tail=if(p.size>=6)p.drop(1).joinToString(" ") else "w - - 0 1"
        return "$board $tail"
    }
    fun applyUci(fen: String, uci: String): String? {
        if(uci.length !in 4..5) return null
        fun idx(s:String):Int { if(s.length!=2 || s[0] !in 'a'..'h' || s[1] !in '1'..'8')return -1; return (8-(s[1]-'0'))*8+(s[0]-'a') }
        val a=idx(uci.substring(0,2)); val b=idx(uci.substring(2,4)); if(a !in 0..63 || b !in 0..63)return null
        val cells=boardChars(fen).toMutableList(); if(cells[a]=='.')return null
        var piece=cells[a]; if(uci.length==5)piece=if(piece.isUpperCase())uci[4].uppercaseChar() else uci[4]
        cells[a]='.'; cells[b]=piece
        val p=fen.trim().split(Regex("\\s+")); val side=if(p.getOrNull(1)=="w")"b" else "w"
        return withBoard(fen,cells).substringBefore(' ') + " $side ${p.getOrNull(2) ?: "-"} - 0 1"
    }
}

object PgnImporter {
    fun tryReadFenOrUci(pgn: String): String? {
        val fen = Regex("""(?m)^\[FEN\s+"([^"]+)"\]""").find(pgn)?.groupValues?.get(1)
        if(fen != null)return fen.takeIf { ChessPosition.isPlausibleFen(it) }
        val body=pgn.lines().filterNot { it.trim().startsWith("[") }.joinToString(" ")
            .replace(Regex("\\{[^}]*}")," ").replace(Regex("\\([^)]*\\)")," ")
        val moves=body.split(Regex("\\s+")).filter { it.isNotBlank() }
            .filterNot { it.matches(Regex("\\d+\\.{1,3}")) || it in listOf("1-0","0-1","1/2-1/2","*") }
        if(moves.isEmpty() || moves.any { !it.matches(Regex("[a-h][1-8][a-h][1-8][qrbnQRBN]?")) })return null
        var result=ChessPosition.START_FEN
        moves.forEach { result=ChessPosition.applyUci(result,it) ?: return null }
        return result
    }
}
